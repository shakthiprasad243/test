import {
  calculateTriangleArea,
  calculateRectangleArea,
  calculateCircleArea,
  calculatePolygonArea,
} from "./survey-calculations"
import { AdvancedImageAnalyzer, type DetectedShape as ProcessorShape } from "./advanced-image-processor"
import { MeasurementParser } from "./handwriting-recognition"

export type ShapeType =
  | "triangle"
  | "rectangle"
  | "square"
  | "circle"
  | "polygon"
  | "trapezoid"
  | "parallelogram"
  | "line"

interface DetectedShape {
  id: string
  type: ShapeType
  coordinates: [number, number][]
  measurements: {
    [key: string]: number // sides, radius, diagonals, etc.
  }
  area: number
  confidence: number
  formula: string
  parentId?: string // If this is a subshape
  subshapes?: DetectedShape[] // Nested shapes within this shape
  isSubshape: boolean
  depth: number // Nesting level (0 = top level, 1 = first level subshape, etc.)
  extractedText?: string[] // OCR text found near this shape
  boundingBox?: {
    x: number
    y: number
    width: number
    height: number
  }
  processingMethod: "ai" | "cv" | "hybrid" // How this shape was detected
}

interface ShapeHierarchy {
  mainShapes: DetectedShape[]
  allShapes: DetectedShape[] // Flattened list including subshapes
  totalMainArea: number // Area of main shapes only
  totalCombinedArea: number // All areas including subshapes
  overlapAdjustedArea: number // Total area with overlap corrections
}

interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  shapeValidation?: {
    shapeId: string
    type: ShapeType
    measurements: { [key: string]: number }
    area: number
    isValidShape: boolean
    validationDetails: string[]
    hierarchyValidation?: {
      hasValidParent: boolean
      subshapeCount: number
      overlapIssues: string[]
    }
  }[]
}

interface EnhancedShapeAnalysis {
  shapes: DetectedShape[]
  hierarchy: ShapeHierarchy
  scale: {
    pixelsPerMeter: number
    confidence: number
  }
  totalArea: number
  notes: string
  provider: "gemini" | "cv" | "hybrid"
  validation?: ValidationResult
  processingDetails: {
    aiDetected: number
    cvDetected: number
    hybridValidated: number
    extractedText: string[]
    processingTime: number
  }
}

function buildShapeHierarchy(shapes: DetectedShape[]): ShapeHierarchy {
  const mainShapes: DetectedShape[] = []
  const allShapes: DetectedShape[] = []

  // Organize shapes by hierarchy
  shapes.forEach((shape) => {
    allShapes.push(shape)
    if (!shape.parentId) {
      mainShapes.push(shape)
    }
  })

  // Attach subshapes to their parents
  mainShapes.forEach((mainShape) => {
    mainShape.subshapes = shapes.filter((s) => s.parentId === mainShape.id)
  })

  const totalMainArea = mainShapes.reduce((sum, shape) => sum + shape.area, 0)
  const totalCombinedArea = allShapes.reduce((sum, shape) => sum + shape.area, 0)

  // Calculate overlap-adjusted area (subtract subshape areas from parent areas)
  let overlapAdjustedArea = totalMainArea
  mainShapes.forEach((mainShape) => {
    if (mainShape.subshapes && mainShape.subshapes.length > 0) {
      const subshapeArea = mainShape.subshapes.reduce((sum, sub) => sum + sub.area, 0)
      // Don't double-count subshape areas
      overlapAdjustedArea -= subshapeArea
    }
  })

  return {
    mainShapes,
    allShapes,
    totalMainArea,
    totalCombinedArea,
    overlapAdjustedArea: Math.max(0, overlapAdjustedArea),
  }
}

function detectOverlaps(shapes: DetectedShape[]): string[] {
  const overlaps: string[] = []

  for (let i = 0; i < shapes.length; i++) {
    for (let j = i + 1; j < shapes.length; j++) {
      const shape1 = shapes[i]
      const shape2 = shapes[j]

      // Check bounding box overlap first (faster)
      if (shape1.boundingBox && shape2.boundingBox) {
        const box1 = shape1.boundingBox
        const box2 = shape2.boundingBox

        const hasBoxOverlap = !(
          box1.x + box1.width < box2.x ||
          box2.x + box2.width < box1.x ||
          box1.y + box1.height < box2.y ||
          box2.y + box2.height < box1.y
        )

        if (hasBoxOverlap) {
          // More detailed coordinate overlap check
          const hasCoordOverlap = shape1.coordinates.some((coord1) =>
            shape2.coordinates.some(
              (coord2) => Math.abs(coord1[0] - coord2[0]) < 10 && Math.abs(coord1[1] - coord2[1]) < 10,
            ),
          )

          if (hasCoordOverlap && !shape1.parentId && !shape2.parentId) {
            overlaps.push(`Potential overlap between ${shape1.id} (${shape1.type}) and ${shape2.id} (${shape2.type})`)
          }
        }
      }
    }
  }

  return overlaps
}

function convertCVShapeToDetectedShape(cvShape: ProcessorShape, index: number): DetectedShape {
  const coordinates: [number, number][] = cvShape.points.map((p) => [p.x, p.y])

  let area = 0
  let formula = ""
  const measurements: { [key: string]: number } = {}

  // Convert measurements based on shape type
  switch (cvShape.type) {
    case "triangle":
      if (cvShape.measurements.sides && cvShape.measurements.sides.length >= 3) {
        const [a, b, c] = cvShape.measurements.sides
        measurements.a = a
        measurements.b = b
        measurements.c = c
        area = calculateTriangleArea(a, b, c)
        formula = "Heron's Formula: √(s(s-a)(s-b)(s-c))"
      }
      break
    case "rectangle":
      if (cvShape.measurements.sides && cvShape.measurements.sides.length >= 2) {
        const [width, height] = cvShape.measurements.sides
        measurements.width = width
        measurements.height = height
        area = calculateRectangleArea(width, height)
        formula = "Rectangle: width × height"
      }
      break
    case "circle":
      if (cvShape.measurements.radius) {
        measurements.radius = cvShape.measurements.radius
        area = calculateCircleArea(cvShape.measurements.radius)
        formula = "Circle: π × radius²"
      }
      break
    case "polygon":
      if (cvShape.measurements.sides) {
        cvShape.measurements.sides.forEach((side, i) => {
          measurements[`side${i + 1}`] = side
        })
      }
      area = calculatePolygonArea(coordinates)
      formula = "Shoelace Formula for irregular polygon"
      break
  }

  return {
    id: cvShape.id,
    type: cvShape.type as ShapeType,
    coordinates,
    measurements,
    area: area || cvShape.measurements.area || 0,
    confidence: cvShape.confidence,
    formula,
    isSubshape: false,
    depth: 0,
    extractedText: cvShape.extractedText,
    boundingBox: cvShape.boundingBox,
    processingMethod: "cv",
  }
}

export function validateShapeDetection(shapes: DetectedShape[]): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  const shapeValidation: ValidationResult["shapeValidation"] = []

  if (shapes.length === 0) {
    errors.push("No shapes detected in the survey image")
    return { isValid: false, errors, warnings }
  }

  const overlapIssues = detectOverlaps(shapes)
  if (overlapIssues.length > 0) {
    warnings.push(...overlapIssues)
  }

  shapes.forEach((shape) => {
    const validationDetails: string[] = []
    let isValidShape = true

    const hierarchyValidation = {
      hasValidParent: !shape.parentId || shapes.some((s) => s.id === shape.parentId),
      subshapeCount: shape.subshapes?.length || 0,
      overlapIssues: overlapIssues.filter((issue) => issue.includes(shape.id)),
    }

    if (shape.confidence < 0.5) {
      warnings.push(`${shape.id}: Low detection confidence (${(shape.confidence * 100).toFixed(1)}%)`)
    } else if (shape.confidence > 0.9) {
      validationDetails.push(`High confidence detection (${(shape.confidence * 100).toFixed(1)}%)`)
    }

    if (shape.parentId && !hierarchyValidation.hasValidParent) {
      errors.push(`${shape.id}: Invalid parent reference ${shape.parentId}`)
      isValidShape = false
    }

    switch (shape.type) {
      case "triangle":
        const { a, b, c } = shape.measurements
        if (a && b && c) {
          // Triangle inequality check
          if (a + b <= c || a + c <= b || b + c <= a) {
            isValidShape = false
            validationDetails.push(`Triangle inequality violated: ${a.toFixed(2)} + ${b.toFixed(2)} ≤ ${c.toFixed(2)}`)
          } else {
            validationDetails.push("Triangle inequality satisfied")
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurements: sides a, b, c")
        }
        break

      case "rectangle":
      case "square":
        const { width, height } = shape.measurements
        if (width && height) {
          if (width <= 0 || height <= 0) {
            isValidShape = false
            validationDetails.push("Width and height must be positive")
          } else {
            validationDetails.push("Rectangle measurements valid")
            if (shape.type === "square" && Math.abs(width - height) > 0.1) {
              warnings.push(`${shape.id}: Square has unequal sides (${width.toFixed(2)} × ${height.toFixed(2)})`)
            }
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurements: width, height")
        }
        break

      case "circle":
        const { radius } = shape.measurements
        if (radius) {
          if (radius <= 0) {
            isValidShape = false
            validationDetails.push("Radius must be positive")
          } else {
            validationDetails.push("Circle measurements valid")
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurement: radius")
        }
        break

      case "polygon":
        const sides = Object.values(shape.measurements).filter((val) => val > 0)
        if (sides.length < 3) {
          isValidShape = false
          validationDetails.push("Polygon must have at least 3 sides")
        } else {
          validationDetails.push(`Polygon with ${sides.length} sides detected`)
        }
        break
    }

    // Check for reasonable measurements
    const measurements = Object.values(shape.measurements)
    measurements.forEach((measurement, index) => {
      if (measurement < 0.1) {
        warnings.push(`${shape.id}: Very small measurement (${measurement.toFixed(2)}m) - check scale`)
      } else if (measurement > 500) {
        warnings.push(`${shape.id}: Very large measurement (${measurement.toFixed(2)}m) - check scale`)
      }
    })

    shapeValidation.push({
      shapeId: shape.id,
      type: shape.type,
      measurements: shape.measurements,
      area: shape.area,
      isValidShape,
      validationDetails,
      hierarchyValidation,
    })

    if (!isValidShape) {
      errors.push(`${shape.id}: Invalid ${shape.type} - ${validationDetails.join(", ")}`)
    }
  })

  const isValid = errors.length === 0

  if (isValid && warnings.length === 0) {
    warnings.push("All shapes passed validation checks")
  }

  return {
    isValid,
    errors,
    warnings,
    shapeValidation,
  }
}

export async function analyzeShapesHybrid(imageData: string): Promise<EnhancedShapeAnalysis> {
  const startTime = Date.now()

  try {
    const measurementParser = new MeasurementParser()
    const surveyMeasurements = await measurementParser.parseSurveyMeasurements(imageData)

    // Step 1: Try computer vision analysis first
    const cvAnalyzer = new AdvancedImageAnalyzer()
    const cvResult = await cvAnalyzer.analyzeImage(imageData)

    // Step 2: Convert CV shapes to our format
    const cvShapes = cvResult.shapes.map((shape, index) => convertCVShapeToDetectedShape(shape, index))

    // Step 3: Try AI analysis as backup/enhancement
    let aiShapes: DetectedShape[] = []
    try {
      const aiResult = await analyzeShapesWithGemini(imageData)
      aiShapes = aiResult.shapes.map((shape) => ({
        ...shape,
        processingMethod: "ai" as const,
      }))
    } catch (error) {
      console.warn("AI analysis failed, using CV results only:", error)
    }

    const enhancedShapes = await enhanceShapesWithMeasurements([...cvShapes, ...aiShapes], surveyMeasurements)

    // Step 5: Combine and validate results
    const deduplicatedShapes = deduplicateShapes(enhancedShapes)

    // Step 6: Build hierarchy and calculate areas
    const hierarchy = buildShapeHierarchy(deduplicatedShapes)

    // Step 7: Extract scale information
    const scaleInfo = cvResult.scaleInfo || { pixelsPerMeter: 1, confidence: 0.5 }

    const processingTime = Date.now() - startTime

    const analysisData: EnhancedShapeAnalysis = {
      shapes: deduplicatedShapes,
      hierarchy,
      scale: {
        pixelsPerMeter: scaleInfo.pixelsPerUnit,
        confidence: scaleInfo.confidence,
      },
      totalArea: hierarchy.overlapAdjustedArea,
      notes: `Hybrid analysis with handwriting recognition completed in ${processingTime}ms`,
      provider: "hybrid",
      processingDetails: {
        aiDetected: aiShapes.length,
        cvDetected: cvShapes.length,
        hybridValidated: deduplicatedShapes.length,
        extractedText: [
          ...cvResult.extractedText,
          ...surveyMeasurements.measurements.map((m) => `${m.value} ${m.unit}`),
        ],
        processingTime,
      },
    }

    const validation = validateShapeDetectionWithGeometry(analysisData.shapes, surveyMeasurements)

    return {
      ...analysisData,
      validation,
    }
  } catch (error) {
    console.error("Hybrid analysis failed:", error)
    throw error
  }
}

/**
 * Enhance detected shapes with handwriting measurements
 */
async function enhanceShapesWithMeasurements(
  shapes: DetectedShape[],
  surveyMeasurements: any,
): Promise<DetectedShape[]> {
  return shapes.map((shape) => {
    const nearbyMeasurements = surveyMeasurements.measurements.filter((measurement: any) => {
      if (!shape.boundingBox) return false

      const shapeCenter = {
        x: shape.boundingBox.x + shape.boundingBox.width / 2,
        y: shape.boundingBox.y + shape.boundingBox.height / 2,
      }

      const distance = Math.sqrt(
        Math.pow(measurement.position.x - shapeCenter.x, 2) + Math.pow(measurement.position.y - shapeCenter.y, 2),
      )

      return distance < 100 // Within 100 pixels
    })

    if (nearbyMeasurements.length > 0 && shape.type === "triangle") {
      const measurements = nearbyMeasurements.slice(0, 3) // Take first 3 measurements
      if (measurements.length === 3) {
        shape.measurements = {
          a: measurements[0].value,
          b: measurements[1].value,
          c: measurements[2].value,
        }

        // Recalculate area with new measurements
        shape.area = calculateTriangleArea(measurements[0].value, measurements[1].value, measurements[2].value)
        shape.confidence = Math.min(shape.confidence + 0.2, 0.95) // Boost confidence
      }
    }

    return shape
  })
}

/**
 * Enhanced validation with geometric checks
 */
function validateShapeDetectionWithGeometry(shapes: DetectedShape[], surveyMeasurements: any): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  const shapeValidation: ValidationResult["shapeValidation"] = []

  surveyMeasurements.validation.forEach((validation: any, index: number) => {
    if (!validation.isValid) {
      errors.push(`Triangle ${index + 1}: ${validation.measurements.errors.join(", ")}`)
      validation.triangleInequality.violations.forEach((violation: string) => {
        warnings.push(`Triangle ${index + 1}: ${violation}`)
      })
    }
  })

  shapes.forEach((shape) => {
    const validationDetails: string[] = []
    let isValidShape = true

    const hierarchyValidation = {
      hasValidParent: !shape.parentId || shapes.some((s) => s.id === shape.parentId),
      subshapeCount: shape.subshapes?.length || 0,
      overlapIssues: [],
    }

    if (shape.confidence < 0.5) {
      warnings.push(`${shape.id}: Low detection confidence (${(shape.confidence * 100).toFixed(1)}%)`)
    } else if (shape.confidence > 0.9) {
      validationDetails.push(`High confidence detection (${(shape.confidence * 100).toFixed(1)}%)`)
    }

    if (shape.parentId && !hierarchyValidation.hasValidParent) {
      errors.push(`${shape.id}: Invalid parent reference ${shape.parentId}`)
      isValidShape = false
    }

    switch (shape.type) {
      case "triangle":
        const { a, b, c } = shape.measurements
        if (a && b && c) {
          // Triangle inequality check
          if (a + b <= c || a + c <= b || b + c <= a) {
            isValidShape = false
            validationDetails.push(`Triangle inequality violated: ${a.toFixed(2)} + ${b.toFixed(2)} ≤ ${c.toFixed(2)}`)
          } else {
            validationDetails.push("Triangle inequality satisfied")
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurements: sides a, b, c")
        }
        break

      case "rectangle":
      case "square":
        const { width, height } = shape.measurements
        if (width && height) {
          if (width <= 0 || height <= 0) {
            isValidShape = false
            validationDetails.push("Width and height must be positive")
          } else {
            validationDetails.push("Rectangle measurements valid")
            if (shape.type === "square" && Math.abs(width - height) > 0.1) {
              warnings.push(`${shape.id}: Square has unequal sides (${width.toFixed(2)} × ${height.toFixed(2)})`)
            }
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurements: width, height")
        }
        break

      case "circle":
        const { radius } = shape.measurements
        if (radius) {
          if (radius <= 0) {
            isValidShape = false
            validationDetails.push("Radius must be positive")
          } else {
            validationDetails.push("Circle measurements valid")
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurement: radius")
        }
        break

      case "polygon":
        const sides = Object.values(shape.measurements).filter((val) => val > 0)
        if (sides.length < 3) {
          isValidShape = false
          validationDetails.push("Polygon must have at least 3 sides")
        } else {
          validationDetails.push(`Polygon with ${sides.length} sides detected`)
        }
        break
    }

    // Check for reasonable measurements
    const measurements = Object.values(shape.measurements)
    measurements.forEach((measurement, index) => {
      if (measurement < 0.1) {
        warnings.push(`${shape.id}: Very small measurement (${measurement.toFixed(2)}m) - check scale`)
      } else if (measurement > 500) {
        warnings.push(`${shape.id}: Very large measurement (${measurement.toFixed(2)}m) - check scale`)
      }
    })

    shapeValidation.push({
      shapeId: shape.id,
      type: shape.type,
      measurements: shape.measurements,
      area: shape.area,
      isValidShape,
      validationDetails,
      hierarchyValidation,
    })

    if (!isValidShape) {
      errors.push(`${shape.id}: Invalid ${shape.type} - ${validationDetails.join(", ")}`)
    }
  })

  const isValid = errors.length === 0

  return {
    isValid,
    errors,
    warnings,
    shapeValidation,
  }
}

export async function analyzeShapesWithGemini(imageData: string): Promise<EnhancedShapeAnalysis> {
  const response = await fetch("/api/analyze-shapes-gemini", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ imageData }),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.error || "Failed to analyze with Gemini")
  }

  const result = await response.json()

  const shapesWithAreas = result.data.shapes.map((shape: any) => {
    let area = 0
    let formula = ""

    switch (shape.type) {
      case "triangle":
        const { a, b, c } = shape.measurements
        area = calculateTriangleArea(a, b, c)
        formula = "Heron's Formula: √(s(s-a)(s-b)(s-c))"
        break
      case "rectangle":
        const { width, height } = shape.measurements
        area = calculateRectangleArea(width, height)
        formula = "Rectangle: width × height"
        break
      case "square":
        const { side } = shape.measurements
        area = calculateRectangleArea(side, side)
        formula = "Square: side²"
        break
      case "circle":
        const { radius } = shape.measurements
        area = calculateCircleArea(radius)
        formula = "Circle: π × radius²"
        break
      case "polygon":
        // Use shoelace formula for irregular polygons
        area = calculatePolygonArea(shape.coordinates)
        formula = "Shoelace Formula for irregular polygon"
        break
      default:
        area = shape.area || 0
        formula = "Custom calculation"
    }

    return {
      ...shape,
      area,
      formula,
      isSubshape: !!shape.parentId,
      depth: shape.parentId ? 1 : 0,
      subshapes: [],
      processingMethod: "ai" as const,
    }
  })

  const hierarchy = buildShapeHierarchy(shapesWithAreas)

  const analysisData: EnhancedShapeAnalysis = {
    ...result.data,
    shapes: shapesWithAreas,
    hierarchy,
    totalArea: hierarchy.overlapAdjustedArea,
    provider: "gemini" as const,
    processingDetails: {
      aiDetected: shapesWithAreas.length,
      cvDetected: 0,
      hybridValidated: shapesWithAreas.length,
      extractedText: [],
      processingTime: 0,
    },
  }

  const validation = validateShapeDetection(analysisData.shapes)

  return {
    ...analysisData,
    validation,
  }
}

export async function analyzeShapes(
  imageData: string,
  method: "hybrid" | "ai" | "cv" = "hybrid",
): Promise<{
  result?: EnhancedShapeAnalysis
  error?: string
}> {
  try {
    let result: EnhancedShapeAnalysis

    switch (method) {
      case "hybrid":
        result = await analyzeShapesHybrid(imageData)
        break
      case "ai":
        result = await analyzeShapesWithGemini(imageData)
        break
      case "cv":
        const cvAnalyzer = new AdvancedImageAnalyzer()
        const cvResult = await cvAnalyzer.analyzeImage(imageData)
        const cvShapes = cvResult.shapes.map((shape, index) => convertCVShapeToDetectedShape(shape, index))
        const hierarchy = buildShapeHierarchy(cvShapes)
        result = {
          shapes: cvShapes,
          hierarchy,
          scale: {
            pixelsPerMeter: cvResult.scaleInfo?.pixelsPerUnit || 1,
            confidence: cvResult.scaleInfo?.confidence || 0.5,
          },
          totalArea: hierarchy.overlapAdjustedArea,
          notes: `Computer vision analysis completed`,
          provider: "cv",
          processingDetails: {
            aiDetected: 0,
            cvDetected: cvShapes.length,
            hybridValidated: cvShapes.length,
            extractedText: cvResult.extractedText,
            processingTime: cvResult.processingTime,
          },
          validation: validateShapeDetection(cvShapes),
        }
        break
      default:
        throw new Error(`Unknown analysis method: ${method}`)
    }

    return { result }
  } catch (error: any) {
    const errorMessage = error.message
    if (errorMessage.includes("API key is missing")) {
      return {
        error: "Gemini API key not configured. Please add GOOGLE_GENERATIVE_AI_API_KEY to your environment variables.",
      }
    } else {
      return { error: `Shape analysis failed: ${errorMessage}` }
    }
  }
}

function deduplicateShapes(shapes: DetectedShape[]): DetectedShape[] {
  const deduplicated: DetectedShape[] = []

  for (const shape of shapes) {
    // Check if a similar shape already exists
    const similar = deduplicated.find((existing) => areSimilarShapes(shape, existing))

    if (similar) {
      // Keep the one with higher confidence or merge them
      if (shape.confidence > similar.confidence) {
        // Replace with higher confidence shape
        const index = deduplicated.indexOf(similar)
        deduplicated[index] = {
          ...shape,
          processingMethod: "hybrid",
          confidence: Math.max(shape.confidence, similar.confidence),
        }
      }
    } else {
      deduplicated.push(shape)
    }
  }

  return deduplicated
}

function areSimilarShapes(shape1: DetectedShape, shape2: DetectedShape): boolean {
  // Must be same type
  if (shape1.type !== shape2.type) return false

  // Check if coordinates are similar
  if (shape1.coordinates.length !== shape2.coordinates.length) return false

  const threshold = 20 // pixels
  for (let i = 0; i < shape1.coordinates.length; i++) {
    const [x1, y1] = shape1.coordinates[i]
    const [x2, y2] = shape2.coordinates[i]

    if (Math.abs(x1 - x2) > threshold || Math.abs(y1 - y2) > threshold) {
      return false
    }
  }

  return true
}
