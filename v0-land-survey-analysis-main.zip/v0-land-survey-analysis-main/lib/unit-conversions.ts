// Unit conversion system for land survey measurements
// Handles all standard surveying units and acre conversions

export interface ConversionResult {
  value: number
  unit: string
  formatted: string
}

export interface UnitDefinition {
  name: string
  symbol: string
  toSquareMeters: number // Conversion factor to square meters
  category: "metric" | "imperial" | "survey"
}

// Standard unit definitions
export const AREA_UNITS: Record<string, UnitDefinition> = {
  // Metric units
  sq_mm: { name: "Square Millimeters", symbol: "mm²", toSquareMeters: 0.000001, category: "metric" },
  sq_cm: { name: "Square Centimeters", symbol: "cm²", toSquareMeters: 0.0001, category: "metric" },
  sq_m: { name: "Square Meters", symbol: "m²", toSquareMeters: 1, category: "metric" },
  sq_km: { name: "Square Kilometers", symbol: "km²", toSquareMeters: 1000000, category: "metric" },
  hectare: { name: "Hectares", symbol: "ha", toSquareMeters: 10000, category: "metric" },

  // Imperial units
  sq_in: { name: "Square Inches", symbol: "in²", toSquareMeters: 0.00064516, category: "imperial" },
  sq_ft: { name: "Square Feet", symbol: "ft²", toSquareMeters: 0.092903, category: "imperial" },
  sq_yd: { name: "Square Yards", symbol: "yd²", toSquareMeters: 0.836127, category: "imperial" },
  sq_mi: { name: "Square Miles", symbol: "mi²", toSquareMeters: 2589988.11, category: "imperial" },

  // Survey units
  acre: { name: "Acres", symbol: "ac", toSquareMeters: 4046.856, category: "survey" },
  sq_rod: { name: "Square Rods", symbol: "rod²", toSquareMeters: 25.293, category: "survey" },
  sq_chain: { name: "Square Chains", symbol: "ch²", toSquareMeters: 404.686, category: "survey" },
}

// Acre conversion constants (as specified in requirements)
export const ACRE_CONVERSIONS = {
  SQ_FEET: 43560,
  SQ_INCHES: 6272640,
  SQ_METERS: 4046.856,
}

export class UnitConverter {
  // Convert from one unit to another
  static convert(value: number, fromUnit: string, toUnit: string): ConversionResult {
    if (fromUnit === toUnit) {
      return {
        value,
        unit: toUnit,
        formatted: this.formatValue(value, toUnit),
      }
    }

    const fromDef = AREA_UNITS[fromUnit]
    const toDef = AREA_UNITS[toUnit]

    if (!fromDef || !toDef) {
      throw new Error(`Unknown unit: ${!fromDef ? fromUnit : toUnit}`)
    }

    // Convert to square meters first, then to target unit
    const squareMeters = value * fromDef.toSquareMeters
    const convertedValue = squareMeters / toDef.toSquareMeters

    return {
      value: convertedValue,
      unit: toUnit,
      formatted: this.formatValue(convertedValue, toUnit),
    }
  }

  // Convert area to acres using exact conversion factors
  static toAcres(value: number, fromUnit: string): ConversionResult {
    let acres: number

    switch (fromUnit) {
      case "sq_ft":
        acres = value / ACRE_CONVERSIONS.SQ_FEET
        break
      case "sq_in":
        acres = value / ACRE_CONVERSIONS.SQ_INCHES
        break
      case "sq_m":
        acres = value / ACRE_CONVERSIONS.SQ_METERS
        break
      default:
        // Use general conversion
        const result = this.convert(value, fromUnit, "acre")
        acres = result.value
    }

    return {
      value: acres,
      unit: "acre",
      formatted: this.formatValue(acres, "acre"),
    }
  }

  // Convert acres to other units
  static fromAcres(acres: number, toUnit: string): ConversionResult {
    let value: number

    switch (toUnit) {
      case "sq_ft":
        value = acres * ACRE_CONVERSIONS.SQ_FEET
        break
      case "sq_in":
        value = acres * ACRE_CONVERSIONS.SQ_INCHES
        break
      case "sq_m":
        value = acres * ACRE_CONVERSIONS.SQ_METERS
        break
      default:
        // Use general conversion
        return this.convert(acres, "acre", toUnit)
    }

    return {
      value,
      unit: toUnit,
      formatted: this.formatValue(value, toUnit),
    }
  }

  // Get all conversions for a given value and unit
  static getAllConversions(value: number, fromUnit: string): Record<string, ConversionResult> {
    const conversions: Record<string, ConversionResult> = {}

    Object.keys(AREA_UNITS).forEach((unit) => {
      if (unit !== fromUnit) {
        try {
          conversions[unit] = this.convert(value, fromUnit, unit)
        } catch (error) {
          // Skip invalid conversions
        }
      }
    })

    return conversions
  }

  // Format value with appropriate precision and thousands separators
  static formatValue(value: number, unit: string): string {
    const unitDef = AREA_UNITS[unit]
    if (!unitDef) return value.toString()

    let precision = 2

    // Adjust precision based on unit and value size
    if (value < 0.01) precision = 6
    else if (value < 1) precision = 4
    else if (value > 1000000) precision = 0
    else if (value > 1000) precision = 1

    const formatted = value.toLocaleString("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: precision,
    })

    return `${formatted} ${unitDef.symbol}`
  }

  // Get unit categories for UI organization
  static getUnitsByCategory(): Record<string, UnitDefinition[]> {
    const categories: Record<string, UnitDefinition[]> = {
      metric: [],
      imperial: [],
      survey: [],
    }

    Object.entries(AREA_UNITS).forEach(([key, unit]) => {
      categories[unit.category].push({ ...unit, name: key })
    })

    return categories
  }

  // Validate if a unit exists
  static isValidUnit(unit: string): boolean {
    return unit in AREA_UNITS
  }

  // Get the most appropriate unit for display based on value size
  static getOptimalUnit(value: number, fromUnit: string, category?: "metric" | "imperial" | "survey"): string {
    const conversions = this.getAllConversions(value, fromUnit)

    // Filter by category if specified
    let candidates = Object.entries(conversions)
    if (category) {
      candidates = candidates.filter(([unit]) => AREA_UNITS[unit].category === category)
    }

    // Find unit where value is between 0.1 and 10000 for optimal readability
    const optimal = candidates.find(([unit, result]) => {
      const val = result.value
      return val >= 0.1 && val <= 10000
    })

    return optimal ? optimal[0] : fromUnit
  }
}
