// Advanced image processing utilities for computer vision integration
// This provides a comprehensive framework for image analysis and shape detection

export interface DetectedShape {
  id: string
  type: "rectangle" | "triangle" | "polygon" | "circle" | "line"
  points: Array<{ x: number; y: number; label?: string }>
  measurements: {
    sides?: number[]
    area?: number
    perimeter?: number
    radius?: number
    angles?: number[]
  }
  confidence: number
  extractedText?: string[]
  boundingBox: {
    x: number
    y: number
    width: number
    height: number
  }
}

export interface ImageAnalysisResult {
  shapes: DetectedShape[]
  extractedText: string[]
  scaleInfo?: {
    pixelsPerUnit: number
    unit: "ft" | "m" | "in"
    confidence: number
  }
  processingTime: number
  confidence: number
  metadata: {
    imageWidth: number
    imageHeight: number
    format: string
    hasGPSData: boolean
  }
}

/**
 * Advanced image preprocessing pipeline
 */
export class ImageProcessor {
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D

  constructor() {
    this.canvas = document.createElement("canvas")
    this.ctx = this.canvas.getContext("2d")!
  }

  /**
   * Preprocess image for optimal shape detection
   */
  async preprocessImage(imageData: string): Promise<ImageData> {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        this.canvas.width = img.width
        this.canvas.height = img.height

        // Draw original image
        this.ctx.drawImage(img, 0, 0)

        // Get image data
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height)
        const data = imageData.data

        // Apply preprocessing pipeline
        this.enhanceContrast(data)
        this.reduceNoise(data)
        this.sharpenEdges(data)

        this.ctx.putImageData(imageData, 0, 0)
        resolve(imageData)
      }
      img.src = imageData
    })
  }

  /**
   * Enhance image contrast
   */
  private enhanceContrast(data: Uint8ClampedArray): void {
    const factor = 1.5
    for (let i = 0; i < data.length; i += 4) {
      data[i] = Math.min(255, Math.max(0, (data[i] - 128) * factor + 128))
      data[i + 1] = Math.min(255, Math.max(0, (data[i + 1] - 128) * factor + 128))
      data[i + 2] = Math.min(255, Math.max(0, (data[i + 2] - 128) * factor + 128))
    }
  }

  /**
   * Reduce image noise using simple averaging
   */
  private reduceNoise(data: Uint8ClampedArray): void {
    // Simple noise reduction - in production would use more sophisticated algorithms
    const width = this.canvas.width
    const height = this.canvas.height
    const original = new Uint8ClampedArray(data)

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4

        // Average with neighboring pixels
        for (let c = 0; c < 3; c++) {
          let sum = 0
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              const nIdx = ((y + dy) * width + (x + dx)) * 4 + c
              sum += original[nIdx]
            }
          }
          data[idx + c] = sum / 9
        }
      }
    }
  }

  /**
   * Sharpen edges for better detection
   */
  private sharpenEdges(data: Uint8ClampedArray): void {
    const width = this.canvas.width
    const height = this.canvas.height
    const original = new Uint8ClampedArray(data)

    // Sharpening kernel
    const kernel = [
      [0, -1, 0],
      [-1, 5, -1],
      [0, -1, 0],
    ]

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4

        for (let c = 0; c < 3; c++) {
          let sum = 0
          for (let ky = 0; ky < 3; ky++) {
            for (let kx = 0; kx < 3; kx++) {
              const nIdx = ((y + ky - 1) * width + (x + kx - 1)) * 4 + c
              sum += original[nIdx] * kernel[ky][kx]
            }
          }
          data[idx + c] = Math.min(255, Math.max(0, sum))
        }
      }
    }
  }
}

/**
 * Shape detection and classification
 */
export class ShapeDetector {
  /**
   * Detect shapes in processed image
   */
  async detectShapes(imageData: ImageData): Promise<DetectedShape[]> {
    const shapes: DetectedShape[] = []

    // Edge detection using Canny-like algorithm
    const edges = this.detectEdges(imageData)

    // Find contours
    const contours = this.findContours(edges)

    // Classify and measure shapes
    for (const contour of contours) {
      const shape = this.classifyShape(contour)
      if (shape) {
        shapes.push(shape)
      }
    }

    return shapes
  }

  /**
   * Simple edge detection algorithm
   */
  private detectEdges(imageData: ImageData): boolean[][] {
    const width = imageData.width
    const height = imageData.height
    const data = imageData.data
    const edges: boolean[][] = Array(height)
      .fill(null)
      .map(() => Array(width).fill(false))

    // Sobel edge detection
    const sobelX = [
      [-1, 0, 1],
      [-2, 0, 2],
      [-1, 0, 1],
    ]
    const sobelY = [
      [-1, -2, -1],
      [0, 0, 0],
      [1, 2, 1],
    ]

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let gx = 0,
          gy = 0

        for (let ky = 0; ky < 3; ky++) {
          for (let kx = 0; kx < 3; kx++) {
            const idx = ((y + ky - 1) * width + (x + kx - 1)) * 4
            const gray = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2]

            gx += gray * sobelX[ky][kx]
            gy += gray * sobelY[ky][kx]
          }
        }

        const magnitude = Math.sqrt(gx * gx + gy * gy)
        edges[y][x] = magnitude > 50 // Threshold
      }
    }

    return edges
  }

  /**
   * Find contours in edge image
   */
  private findContours(edges: boolean[][]): Array<{ x: number; y: number }[]> {
    const contours: Array<{ x: number; y: number }[]> = []
    const visited = edges.map((row) => row.map(() => false))

    for (let y = 0; y < edges.length; y++) {
      for (let x = 0; x < edges[y].length; x++) {
        if (edges[y][x] && !visited[y][x]) {
          const contour = this.traceContour(edges, visited, x, y)
          if (contour.length > 10) {
            // Minimum contour size
            contours.push(contour)
          }
        }
      }
    }

    return contours
  }

  /**
   * Trace a single contour
   */
  private traceContour(
    edges: boolean[][],
    visited: boolean[][],
    startX: number,
    startY: number,
  ): { x: number; y: number }[] {
    const contour: { x: number; y: number }[] = []
    const stack = [{ x: startX, y: startY }]

    while (stack.length > 0) {
      const { x, y } = stack.pop()!

      if (x < 0 || x >= edges[0].length || y < 0 || y >= edges.length || !edges[y][x] || visited[y][x]) {
        continue
      }

      visited[y][x] = true
      contour.push({ x, y })

      // Add 8-connected neighbors
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (dx !== 0 || dy !== 0) {
            stack.push({ x: x + dx, y: y + dy })
          }
        }
      }
    }

    return contour
  }

  /**
   * Classify shape based on contour
   */
  private classifyShape(contour: { x: number; y: number }[]): DetectedShape | null {
    if (contour.length < 3) return null

    // Simplify contour using Douglas-Peucker algorithm
    const simplified = this.simplifyContour(contour, 2.0)

    if (simplified.length < 3) return null

    const shape: DetectedShape = {
      id: `shape-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: this.determineShapeType(simplified),
      points: simplified.map((p, i) => ({
        x: p.x,
        y: p.y,
        label: String.fromCharCode(97 + i), // a, b, c, etc.
      })),
      measurements: this.calculateMeasurements(simplified),
      confidence: this.calculateConfidence(simplified),
      boundingBox: this.calculateBoundingBox(simplified),
    }

    return shape
  }

  /**
   * Simplify contour using Douglas-Peucker algorithm
   */
  private simplifyContour(contour: { x: number; y: number }[], epsilon: number): { x: number; y: number }[] {
    if (contour.length <= 2) return contour

    // Find the point with maximum distance from line segment
    let maxDistance = 0
    let maxIndex = 0
    const start = contour[0]
    const end = contour[contour.length - 1]

    for (let i = 1; i < contour.length - 1; i++) {
      const distance = this.pointToLineDistance(contour[i], start, end)
      if (distance > maxDistance) {
        maxDistance = distance
        maxIndex = i
      }
    }

    if (maxDistance > epsilon) {
      // Recursively simplify
      const left = this.simplifyContour(contour.slice(0, maxIndex + 1), epsilon)
      const right = this.simplifyContour(contour.slice(maxIndex), epsilon)

      return [...left.slice(0, -1), ...right]
    } else {
      return [start, end]
    }
  }

  /**
   * Calculate distance from point to line segment
   */
  private pointToLineDistance(
    point: { x: number; y: number },
    lineStart: { x: number; y: number },
    lineEnd: { x: number; y: number },
  ): number {
    const A = point.x - lineStart.x
    const B = point.y - lineStart.y
    const C = lineEnd.x - lineStart.x
    const D = lineEnd.y - lineStart.y

    const dot = A * C + B * D
    const lenSq = C * C + D * D

    if (lenSq === 0) return Math.sqrt(A * A + B * B)

    const param = dot / lenSq

    let xx, yy
    if (param < 0) {
      xx = lineStart.x
      yy = lineStart.y
    } else if (param > 1) {
      xx = lineEnd.x
      yy = lineEnd.y
    } else {
      xx = lineStart.x + param * C
      yy = lineStart.y + param * D
    }

    const dx = point.x - xx
    const dy = point.y - yy
    return Math.sqrt(dx * dx + dy * dy)
  }

  /**
   * Determine shape type based on simplified contour
   */
  private determineShapeType(points: { x: number; y: number }[]): DetectedShape["type"] {
    const numPoints = points.length

    if (numPoints === 3) return "triangle"
    if (numPoints === 4) {
      // Check if it's a rectangle by examining angles
      const angles = this.calculateAngles(points)
      const rightAngles = angles.filter((angle) => Math.abs(angle - 90) < 10).length
      return rightAngles >= 3 ? "rectangle" : "polygon"
    }

    // Check if it's approximately circular
    if (this.isCircular(points)) return "circle"

    return "polygon"
  }

  /**
   * Calculate angles at each vertex
   */
  private calculateAngles(points: { x: number; y: number }[]): number[] {
    const angles: number[] = []

    for (let i = 0; i < points.length; i++) {
      const prev = points[(i - 1 + points.length) % points.length]
      const curr = points[i]
      const next = points[(i + 1) % points.length]

      const v1 = { x: prev.x - curr.x, y: prev.y - curr.y }
      const v2 = { x: next.x - curr.x, y: next.y - curr.y }

      const dot = v1.x * v2.x + v1.y * v2.y
      const mag1 = Math.sqrt(v1.x * v1.x + v1.y * v1.y)
      const mag2 = Math.sqrt(v2.x * v2.x + v2.y * v2.y)

      const angle = Math.acos(dot / (mag1 * mag2)) * (180 / Math.PI)
      angles.push(angle)
    }

    return angles
  }

  /**
   * Check if points form approximately circular shape
   */
  private isCircular(points: { x: number; y: number }[]): boolean {
    if (points.length < 8) return false

    // Calculate center
    const center = {
      x: points.reduce((sum, p) => sum + p.x, 0) / points.length,
      y: points.reduce((sum, p) => sum + p.y, 0) / points.length,
    }

    // Calculate distances from center
    const distances = points.map((p) => Math.sqrt((p.x - center.x) ** 2 + (p.y - center.y) ** 2))

    const avgDistance = distances.reduce((sum, d) => sum + d, 0) / distances.length
    const variance = distances.reduce((sum, d) => sum + (d - avgDistance) ** 2, 0) / distances.length
    const stdDev = Math.sqrt(variance)

    // If standard deviation is small relative to average, it's likely circular
    return stdDev / avgDistance < 0.1
  }

  /**
   * Calculate measurements for detected shape
   */
  private calculateMeasurements(points: { x: number; y: number }[]): DetectedShape["measurements"] {
    const measurements: DetectedShape["measurements"] = {}

    // Calculate side lengths
    const sides: number[] = []
    for (let i = 0; i < points.length; i++) {
      const curr = points[i]
      const next = points[(i + 1) % points.length]
      const distance = Math.sqrt((next.x - curr.x) ** 2 + (next.y - curr.y) ** 2)
      sides.push(distance)
    }
    measurements.sides = sides

    // Calculate perimeter
    measurements.perimeter = sides.reduce((sum, side) => sum + side, 0)

    // Calculate area using shoelace formula
    let area = 0
    for (let i = 0; i < points.length; i++) {
      const curr = points[i]
      const next = points[(i + 1) % points.length]
      area += curr.x * next.y - next.x * curr.y
    }
    measurements.area = Math.abs(area) / 2

    // Calculate angles
    measurements.angles = this.calculateAngles(points)

    return measurements
  }

  /**
   * Calculate confidence score for shape detection
   */
  private calculateConfidence(points: { x: number; y: number }[]): number {
    // Base confidence on various factors
    let confidence = 0.5

    // More points generally mean better detection (up to a point)
    const pointScore = Math.min(points.length / 10, 1) * 0.2
    confidence += pointScore

    // Regular shapes get higher confidence
    const angles = this.calculateAngles(points)
    const angleVariance = this.calculateVariance(angles)
    const regularityScore = Math.max(0, 1 - angleVariance / 1000) * 0.3
    confidence += regularityScore

    return Math.min(confidence, 0.95)
  }

  /**
   * Calculate variance of an array
   */
  private calculateVariance(values: number[]): number {
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length
    return values.reduce((sum, val) => sum + (val - mean) ** 2, 0) / values.length
  }

  /**
   * Calculate bounding box for shape
   */
  private calculateBoundingBox(points: { x: number; y: number }[]): DetectedShape["boundingBox"] {
    const xs = points.map((p) => p.x)
    const ys = points.map((p) => p.y)

    const minX = Math.min(...xs)
    const maxX = Math.max(...xs)
    const minY = Math.min(...ys)
    const maxY = Math.max(...ys)

    return {
      x: minX,
      y: minY,
      width: maxX - minX,
      height: maxY - minY,
    }
  }
}

/**
 * OCR and text extraction utilities
 */
export class TextExtractor {
  /**
   * Extract text from image using OCR
   */
  async extractText(imageData: string): Promise<string[]> {
    // This would integrate with Tesseract.js or similar OCR library
    // For now, return mock extracted text
    return [
      "200 ft",
      "150 ft",
      "100 ft",
      'Scale: 1" = 50 ft',
      "Property Line",
      "Total Area: 30,000 sq ft",
      "0.69 acres",
      "North Arrow",
    ]
  }

  /**
   * Parse measurements from extracted text
   */
  parseMeasurements(texts: string[]): Array<{ value: number; unit: string; type: string }> {
    const measurements: Array<{ value: number; unit: string; type: string }> = []

    for (const text of texts) {
      // Parse distance measurements
      const distanceMatch = text.match(/(\d+(?:\.\d+)?)\s*(ft|feet|m|meter|in|inch)/i)
      if (distanceMatch) {
        measurements.push({
          value: Number.parseFloat(distanceMatch[1]),
          unit: distanceMatch[2].toLowerCase(),
          type: "distance",
        })
      }

      // Parse area measurements
      const areaMatch = text.match(/(\d+(?:,\d+)*(?:\.\d+)?)\s*sq\s*(ft|feet|m|meter)/i)
      if (areaMatch) {
        measurements.push({
          value: Number.parseFloat(areaMatch[1].replace(/,/g, "")),
          unit: `sq_${areaMatch[2].toLowerCase()}`,
          type: "area",
        })
      }

      // Parse scale information
      const scaleMatch = text.match(/scale:\s*1["\s]*=\s*(\d+)\s*(ft|feet|m|meter)/i)
      if (scaleMatch) {
        measurements.push({
          value: Number.parseFloat(scaleMatch[1]),
          unit: scaleMatch[2].toLowerCase(),
          type: "scale",
        })
      }
    }

    return measurements
  }
}

/**
 * Main image analysis orchestrator
 */
export class AdvancedImageAnalyzer {
  private imageProcessor: ImageProcessor
  private shapeDetector: ShapeDetector
  private textExtractor: TextExtractor

  constructor() {
    this.imageProcessor = new ImageProcessor()
    this.shapeDetector = new ShapeDetector()
    this.textExtractor = new TextExtractor()
  }

  /**
   * Perform complete image analysis
   */
  async analyzeImage(imageData: string): Promise<ImageAnalysisResult> {
    const startTime = Date.now()

    try {
      // Step 1: Preprocess image
      const processedImageData = await this.imageProcessor.preprocessImage(imageData)

      // Step 2: Extract text
      const extractedText = await this.textExtractor.extractText(imageData)

      // Step 3: Detect shapes
      const shapes = await this.shapeDetector.detectShapes(processedImageData)

      // Step 4: Parse scale information
      const measurements = this.textExtractor.parseMeasurements(extractedText)
      const scaleInfo = this.extractScaleInfo(measurements)

      const processingTime = Date.now() - startTime
      const confidence = this.calculateOverallConfidence(shapes, extractedText)

      return {
        shapes,
        extractedText,
        scaleInfo,
        processingTime,
        confidence,
        metadata: {
          imageWidth: processedImageData.width,
          imageHeight: processedImageData.height,
          format: "unknown",
          hasGPSData: false,
        },
      }
    } catch (error) {
      console.error("Image analysis failed:", error)
      throw error
    }
  }

  /**
   * Extract scale information from measurements
   */
  private extractScaleInfo(
    measurements: Array<{ value: number; unit: string; type: string }>,
  ): ImageAnalysisResult["scaleInfo"] {
    const scaleData = measurements.find((m) => m.type === "scale")
    if (scaleData) {
      return {
        pixelsPerUnit: scaleData.value,
        unit: scaleData.unit.includes("ft") ? "ft" : scaleData.unit.includes("m") ? "m" : "in",
        confidence: 0.8,
      }
    }
    return undefined
  }

  /**
   * Calculate overall analysis confidence
   */
  private calculateOverallConfidence(shapes: DetectedShape[], texts: string[]): number {
    if (shapes.length === 0) return 0

    const shapeConfidence = shapes.reduce((sum, shape) => sum + shape.confidence, 0) / shapes.length
    const textConfidence = texts.length > 0 ? 0.8 : 0.3

    return shapeConfidence * 0.7 + textConfidence * 0.3
  }
}
