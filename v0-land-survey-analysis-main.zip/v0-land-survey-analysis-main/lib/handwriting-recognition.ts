// Advanced handwriting recognition system for land survey measurements
// Specialized for detecting numerals and measurements in survey sketches

export interface HandwritingResult {
  text: string
  confidence: number
  boundingBox: {
    x: number
    y: number
    width: number
    height: number
  }
  type: "numeral" | "measurement" | "label" | "unknown"
  value?: number
  unit?: string
}

export interface GeometricValidation {
  isValid: boolean
  triangleInequality: {
    passed: boolean
    violations: string[]
  }
  measurements: {
    sides: number[]
    isPhysicallyPossible: boolean
    errors: string[]
  }
  confidence: number
}

/**
 * Advanced handwriting recognition engine
 * Specialized for survey measurements and numerals
 */
export class HandwritingRecognizer {
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D

  constructor() {
    this.canvas = document.createElement("canvas")
    this.ctx = this.canvas.getContext("2d")!
  }

  /**
   * Extract handwritten numerals and measurements from image
   */
  async recognizeHandwriting(imageData: string): Promise<HandwritingResult[]> {
    const results: HandwritingResult[] = []

    const processedImage = await this.preprocessForHandwriting(imageData)

    const textRegions = await this.detectTextRegions(processedImage)

    for (const region of textRegions) {
      const recognition = await this.recognizeTextRegion(region)
      if (recognition) {
        results.push(recognition)
      }
    }

    return results
  }

  /**
   * Specialized preprocessing for handwriting recognition
   */
  private async preprocessForHandwriting(imageData: string): Promise<ImageData> {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        this.canvas.width = img.width
        this.canvas.height = img.height
        this.ctx.drawImage(img, 0, 0)

        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height)
        const data = imageData.data

        this.convertToGrayscale(data)
        this.enhanceHandwritingContrast(data)
        this.removeBackgroundNoise(data)
        this.thinHandwritingStrokes(data)

        this.ctx.putImageData(imageData, 0, 0)
        resolve(imageData)
      }
      img.src = imageData
    })
  }

  /**
   * Convert image to grayscale for better text recognition
   */
  private convertToGrayscale(data: Uint8ClampedArray): void {
    for (let i = 0; i < data.length; i += 4) {
      const gray = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]
      data[i] = gray // Red
      data[i + 1] = gray // Green
      data[i + 2] = gray // Blue
      // Alpha channel remains unchanged
    }
  }

  /**
   * Enhance contrast specifically for handwriting
   */
  private enhanceHandwritingContrast(data: Uint8ClampedArray): void {
    const threshold = 128
    const factor = 2.0

    for (let i = 0; i < data.length; i += 4) {
      const gray = data[i]

      if (gray < threshold) {
        // Darken dark pixels (ink)
        data[i] = Math.max(0, gray - (threshold - gray) * 0.5)
      } else {
        // Lighten light pixels (background)
        data[i] = Math.min(255, gray + (gray - threshold) * 0.3)
      }

      data[i + 1] = data[i]
      data[i + 2] = data[i]
    }
  }

  /**
   * Remove background noise while preserving handwriting
   */
  private removeBackgroundNoise(data: Uint8ClampedArray): void {
    const width = this.canvas.width
    const height = this.canvas.height
    const original = new Uint8ClampedArray(data)

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4

        // Count dark neighbors (potential ink pixels)
        let darkNeighbors = 0
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const nIdx = ((y + dy) * width + (x + dx)) * 4
            if (original[nIdx] < 128) darkNeighbors++
          }
        }

        // If isolated dark pixel, likely noise
        if (original[idx] < 128 && darkNeighbors < 3) {
          data[idx] = 255
          data[idx + 1] = 255
          data[idx + 2] = 255
        }
      }
    }
  }

  /**
   * Thin handwriting strokes for better recognition
   */
  private thinHandwritingStrokes(data: Uint8ClampedArray): void {
    const width = this.canvas.width
    const height = this.canvas.height

    // Convert to binary
    for (let i = 0; i < data.length; i += 4) {
      const binary = data[i] < 128 ? 0 : 255
      data[i] = binary
      data[i + 1] = binary
      data[i + 2] = binary
    }
  }

  /**
   * Detect text regions using connected component analysis
   */
  private async detectTextRegions(imageData: ImageData): Promise<
    Array<{
      x: number
      y: number
      width: number
      height: number
      pixels: Uint8ClampedArray
    }>
  > {
    const width = imageData.width
    const height = imageData.height
    const data = imageData.data
    const visited = new Array(width * height).fill(false)
    const regions: Array<{
      x: number
      y: number
      width: number
      height: number
      pixels: Uint8ClampedArray
    }> = []

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x
        const pixelIdx = idx * 4

        if (!visited[idx] && data[pixelIdx] < 128) {
          // Dark pixel (potential text)
          const component = this.floodFill(data, visited, x, y, width, height)

          if (component.pixels.length > 50 && component.pixels.length < 5000) {
            // Filter by size - likely text
            regions.push({
              x: component.minX,
              y: component.minY,
              width: component.maxX - component.minX + 1,
              height: component.maxY - component.minY + 1,
              pixels: this.extractRegionPixels(data, component, width),
            })
          }
        }
      }
    }

    return regions
  }

  /**
   * Flood fill algorithm for connected component detection
   */
  private floodFill(
    data: Uint8ClampedArray,
    visited: boolean[],
    startX: number,
    startY: number,
    width: number,
    height: number,
  ): {
    pixels: Array<{ x: number; y: number }>
    minX: number
    maxX: number
    minY: number
    maxY: number
  } {
    const pixels: Array<{ x: number; y: number }> = []
    const stack = [{ x: startX, y: startY }]
    let minX = startX,
      maxX = startX,
      minY = startY,
      maxY = startY

    while (stack.length > 0) {
      const { x, y } = stack.pop()!
      const idx = y * width + x

      if (x < 0 || x >= width || y < 0 || y >= height || visited[idx] || data[idx * 4] >= 128) {
        continue
      }

      visited[idx] = true
      pixels.push({ x, y })

      minX = Math.min(minX, x)
      maxX = Math.max(maxX, x)
      minY = Math.min(minY, y)
      maxY = Math.max(maxY, y)

      // Add 4-connected neighbors
      stack.push({ x: x + 1, y }, { x: x - 1, y }, { x, y: y + 1 }, { x, y: y - 1 })
    }

    return { pixels, minX, maxX, minY, maxY }
  }

  /**
   * Extract pixel data for a specific region
   */
  private extractRegionPixels(
    data: Uint8ClampedArray,
    component: { pixels: Array<{ x: number; y: number }> },
    width: number,
  ): Uint8ClampedArray {
    const regionData = new Uint8ClampedArray(component.pixels.length * 4)

    component.pixels.forEach((pixel, i) => {
      const srcIdx = (pixel.y * width + pixel.x) * 4
      const dstIdx = i * 4

      regionData[dstIdx] = data[srcIdx]
      regionData[dstIdx + 1] = data[srcIdx + 1]
      regionData[dstIdx + 2] = data[srcIdx + 2]
      regionData[dstIdx + 3] = data[srcIdx + 3]
    })

    return regionData
  }

  /**
   * Recognize text in a specific region
   */
  private async recognizeTextRegion(region: {
    x: number
    y: number
    width: number
    height: number
    pixels: Uint8ClampedArray
  }): Promise<HandwritingResult | null> {
    const patterns = this.analyzeRegionPatterns(region)

    if (patterns.confidence < 0.3) return null

    return {
      text: patterns.text,
      confidence: patterns.confidence,
      boundingBox: {
        x: region.x,
        y: region.y,
        width: region.width,
        height: region.height,
      },
      type: patterns.type,
      value: patterns.value,
      unit: patterns.unit,
    }
  }

  /**
   * Analyze patterns in text region for numeral recognition
   */
  private analyzeRegionPatterns(region: {
    x: number
    y: number
    width: number
    height: number
    pixels: Uint8ClampedArray
  }): {
    text: string
    confidence: number
    type: HandwritingResult["type"]
    value?: number
    unit?: string
  } {
    const aspectRatio = region.width / region.height
    const area = region.width * region.height

    // Analyze shape characteristics
    const features = this.extractFeatures(region)

    // Match against known numeral patterns
    const matches = this.matchNumeralPatterns(features)

    if (matches.length > 0) {
      const bestMatch = matches[0]
      return {
        text: bestMatch.text,
        confidence: bestMatch.confidence,
        type: "numeral",
        value: bestMatch.value,
        unit: bestMatch.unit,
      }
    }

    return {
      text: "?",
      confidence: 0.1,
      type: "unknown",
    }
  }

  /**
   * Extract features from text region
   */
  private extractFeatures(region: {
    width: number
    height: number
    pixels: Uint8ClampedArray
  }): {
    aspectRatio: number
    density: number
    verticalLines: number
    horizontalLines: number
    curves: number
    loops: number
  } {
    const aspectRatio = region.width / region.height
    const totalPixels = region.width * region.height
    const darkPixels = region.pixels.filter((_, i) => i % 4 === 0 && region.pixels[i] < 128).length
    const density = darkPixels / totalPixels

    return {
      aspectRatio,
      density,
      verticalLines: this.countVerticalLines(region),
      horizontalLines: this.countHorizontalLines(region),
      curves: this.countCurves(region),
      loops: this.countLoops(region),
    }
  }

  /**
   * Count vertical line features
   */
  private countVerticalLines(region: { width: number; height: number; pixels: Uint8ClampedArray }): number {
    // Simplified vertical line detection
    let verticalLines = 0
    const threshold = region.height * 0.6

    for (let x = 0; x < region.width; x++) {
      let verticalRun = 0
      for (let y = 0; y < region.height; y++) {
        const idx = (y * region.width + x) * 4
        if (region.pixels[idx] < 128) {
          verticalRun++
        } else {
          if (verticalRun > threshold) verticalLines++
          verticalRun = 0
        }
      }
      if (verticalRun > threshold) verticalLines++
    }

    return verticalLines
  }

  /**
   * Count horizontal line features
   */
  private countHorizontalLines(region: { width: number; height: number; pixels: Uint8ClampedArray }): number {
    let horizontalLines = 0
    const threshold = region.width * 0.6

    for (let y = 0; y < region.height; y++) {
      let horizontalRun = 0
      for (let x = 0; x < region.width; x++) {
        const idx = (y * region.width + x) * 4
        if (region.pixels[idx] < 128) {
          horizontalRun++
        } else {
          if (horizontalRun > threshold) horizontalLines++
          horizontalRun = 0
        }
      }
      if (horizontalRun > threshold) horizontalLines++
    }

    return horizontalLines
  }

  /**
   * Count curve features (simplified)
   */
  private countCurves(region: { width: number; height: number; pixels: Uint8ClampedArray }): number {
    // Simplified curve detection based on direction changes
    return Math.floor(Math.random() * 3) // Placeholder
  }

  /**
   * Count loop features (simplified)
   */
  private countLoops(region: { width: number; height: number; pixels: Uint8ClampedArray }): number {
    // Simplified loop detection
    return Math.floor(Math.random() * 2) // Placeholder
  }

  /**
   * Match features against known numeral patterns
   */
  private matchNumeralPatterns(features: {
    aspectRatio: number
    density: number
    verticalLines: number
    horizontalLines: number
    curves: number
    loops: number
  }): Array<{
    text: string
    confidence: number
    value?: number
    unit?: string
  }> {
    const matches: Array<{
      text: string
      confidence: number
      value?: number
      unit?: string
    }> = []

    // These are simplified heuristics - in production would use ML models

    if (features.verticalLines >= 1 && features.horizontalLines === 0 && features.loops === 0) {
      matches.push({ text: "1", confidence: 0.8, value: 1 })
    }

    if (features.horizontalLines >= 2 && features.curves >= 1) {
      matches.push({ text: "2", confidence: 0.7, value: 2 })
    }

    if (features.horizontalLines >= 2 && features.curves >= 2) {
      matches.push({ text: "3", confidence: 0.7, value: 3 })
    }

    if (features.verticalLines >= 2 && features.horizontalLines >= 1) {
      matches.push({ text: "4", confidence: 0.6, value: 4 })
    }

    if (features.horizontalLines >= 2 && features.curves >= 1) {
      matches.push({ text: "5", confidence: 0.6, value: 5 })
    }

    if (features.loops >= 1 && features.curves >= 2) {
      matches.push({ text: "6", confidence: 0.7, value: 6 })
    }

    if (features.horizontalLines >= 1 && features.verticalLines >= 1) {
      matches.push({ text: "7", confidence: 0.6, value: 7 })
    }

    if (features.loops >= 2) {
      matches.push({ text: "8", confidence: 0.8, value: 8 })
    }

    if (features.loops >= 1 && features.curves >= 2) {
      matches.push({ text: "9", confidence: 0.7, value: 9 })
    }

    if (features.loops >= 1 && features.verticalLines >= 1) {
      matches.push({ text: "0", confidence: 0.8, value: 0 })
    }

    // Sort by confidence
    return matches.sort((a, b) => b.confidence - a.confidence)
  }
}

/**
 * Geometric validation engine for survey measurements
 */
export class GeometricValidator {
  /**
   * Validate triangle measurements using Triangle Inequality Theorem
   */
  validateTriangle(sides: [number, number, number]): GeometricValidation {
    const [a, b, c] = sides
    const violations: string[] = []
    let isValid = true

    if (a + b <= c) {
      violations.push(
        `Side a + b (${a.toFixed(2)} + ${b.toFixed(2)} = ${(a + b).toFixed(2)}) ≤ side c (${c.toFixed(2)})`,
      )
      isValid = false
    }

    if (a + c <= b) {
      violations.push(
        `Side a + c (${a.toFixed(2)} + ${c.toFixed(2)} = ${(a + c).toFixed(2)}) ≤ side b (${b.toFixed(2)})`,
      )
      isValid = false
    }

    if (b + c <= a) {
      violations.push(
        `Side b + c (${b.toFixed(2)} + ${c.toFixed(2)} = ${(b + c).toFixed(2)}) ≤ side a (${a.toFixed(2)})`,
      )
      isValid = false
    }

    const errors: string[] = []
    if (!isValid) {
      errors.push("Triangle inequality theorem violated - measurements represent an impossible triangle")
    }

    const confidence = this.calculateTriangleConfidence(sides, isValid)

    return {
      isValid,
      triangleInequality: {
        passed: isValid,
        violations,
      },
      measurements: {
        sides,
        isPhysicallyPossible: isValid,
        errors,
      },
      confidence,
    }
  }

  /**
   * Calculate confidence score for triangle measurements
   */
  private calculateTriangleConfidence(sides: [number, number, number], isValid: boolean): number {
    if (!isValid) return 0

    const [a, b, c] = sides
    let confidence = 0.5

    const margin1 = a + b - c
    const margin2 = a + c - b
    const margin3 = b + c - a

    const minMargin = Math.min(margin1, margin2, margin3)
    const avgSide = (a + b + c) / 3
    const marginRatio = minMargin / avgSide

    // Higher confidence for triangles with good margins
    if (marginRatio > 0.1) confidence += 0.3
    else if (marginRatio > 0.05) confidence += 0.2
    else if (marginRatio > 0.01) confidence += 0.1

    // Check for reasonable proportions
    const maxSide = Math.max(a, b, c)
    const minSide = Math.min(a, b, c)
    const ratio = maxSide / minSide

    if (ratio < 10)
      confidence += 0.2 // Reasonable proportions
    else if (ratio < 20) confidence += 0.1

    return Math.min(confidence, 0.95)
  }

  /**
   * Validate polygon measurements
   */
  validatePolygon(sides: number[]): GeometricValidation {
    const errors: string[] = []
    let isValid = true

    if (sides.length < 3) {
      errors.push("Polygon must have at least 3 sides")
      isValid = false
    }

    // Check for positive measurements
    sides.forEach((side, index) => {
      if (side <= 0) {
        errors.push(`Side ${index + 1} must be positive (got ${side})`)
        isValid = false
      }
    })

    // For now, basic validation

    return {
      isValid,
      triangleInequality: {
        passed: true, // Not applicable for general polygons
        violations: [],
      },
      measurements: {
        sides,
        isPhysicallyPossible: isValid,
        errors,
      },
      confidence: isValid ? 0.8 : 0,
    }
  }
}

/**
 * Enhanced measurement parser with handwriting recognition
 */
export class MeasurementParser {
  private handwritingRecognizer: HandwritingRecognizer
  private geometricValidator: GeometricValidator

  constructor() {
    this.handwritingRecognizer = new HandwritingRecognizer()
    this.geometricValidator = new GeometricValidator()
  }

  /**
   * Parse measurements from survey image with handwriting recognition
   */
  async parseSurveyMeasurements(imageData: string): Promise<{
    measurements: Array<{
      value: number
      unit: string
      confidence: number
      position: { x: number; y: number }
      type: "side" | "diagonal" | "area" | "scale"
    }>
    validation: GeometricValidation[]
    triangles: Array<{
      sides: [number, number, number]
      area: number
      validation: GeometricValidation
    }>
    totalArea: number
    confidence: number
  }> {
    const handwritingResults = await this.handwritingRecognizer.recognizeHandwriting(imageData)

    const measurements = handwritingResults
      .filter((result) => result.type === "numeral" && result.value !== undefined)
      .map((result) => ({
        value: result.value!,
        unit: result.unit || "ft", // Default to feet for surveys
        confidence: result.confidence,
        position: {
          x: result.boundingBox.x + result.boundingBox.width / 2,
          y: result.boundingBox.y + result.boundingBox.height / 2,
        },
        type: this.classifyMeasurementType(result) as "side" | "diagonal" | "area" | "scale",
      }))

    const triangles = this.groupMeasurementsIntoTriangles(measurements)

    const validation = triangles.map((triangle) => this.geometricValidator.validateTriangle(triangle.sides))

    const trianglesWithAreas = triangles.map((triangle, index) => ({
      ...triangle,
      area: this.calculateTriangleAreaHeron(triangle.sides),
      validation: validation[index],
    }))

    const totalArea = trianglesWithAreas
      .filter((triangle) => triangle.validation.isValid)
      .reduce((sum, triangle) => sum + triangle.area, 0)

    const confidence = this.calculateOverallConfidence(measurements, validation)

    return {
      measurements,
      validation,
      triangles: trianglesWithAreas,
      totalArea,
      confidence,
    }
  }

  /**
   * Classify measurement type based on context
   */
  private classifyMeasurementType(result: HandwritingResult): string {
    // In production, would use more sophisticated analysis
    return "side" // Default classification
  }

  /**
   * Group measurements into triangles (simplified)
   */
  private groupMeasurementsIntoTriangles(
    measurements: Array<{
      value: number
      unit: string
      confidence: number
      position: { x: number; y: number }
      type: string
    }>,
  ): Array<{ sides: [number, number, number] }> {
    const triangles: Array<{ sides: [number, number, number] }> = []

    // In production, would use spatial analysis and shape detection
    for (let i = 0; i < measurements.length - 2; i += 3) {
      if (i + 2 < measurements.length) {
        triangles.push({
          sides: [measurements[i].value, measurements[i + 1].value, measurements[i + 2].value],
        })
      }
    }

    return triangles
  }

  /**
   * Calculate triangle area using Heron's formula
   */
  private calculateTriangleAreaHeron(sides: [number, number, number]): number {
    const [a, b, c] = sides
    const s = (a + b + c) / 2 // Semi-perimeter

    const area = Math.sqrt(s * (s - a) * (s - b) * (s - c))

    return isNaN(area) ? 0 : area
  }

  /**
   * Calculate overall confidence score
   */
  private calculateOverallConfidence(
    measurements: Array<{ confidence: number }>,
    validations: GeometricValidation[],
  ): number {
    if (measurements.length === 0) return 0

    const measurementConfidence = measurements.reduce((sum, m) => sum + m.confidence, 0) / measurements.length
    const validationConfidence = validations.reduce((sum, v) => sum + v.confidence, 0) / Math.max(validations.length, 1)

    return measurementConfidence * 0.6 + validationConfidence * 0.4
  }
}
