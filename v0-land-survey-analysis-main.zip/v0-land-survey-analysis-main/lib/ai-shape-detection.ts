import {
  calculateTriangleArea,
  calculateRectangleArea,
  calculateCircleArea,
  calculatePolygonArea,
} from "./survey-calculations"

export type ShapeType = "triangle" | "rectangle" | "square" | "circle" | "polygon" | "trapezoid" | "parallelogram"

interface DetectedShape {
  id: string
  type: ShapeType
  coordinates: [number, number][]
  measurements: {
    [key: string]: number // sides, radius, diagonals, etc.
  }
  area: number
  confidence: number
  formula: string
  parentId?: string // If this is a subshape
  subshapes?: DetectedShape[] // Nested shapes within this shape
  isSubshape: boolean
  depth: number // Nesting level (0 = top level, 1 = first level subshape, etc.)
}

interface ShapeHierarchy {
  mainShapes: DetectedShape[]
  allShapes: DetectedShape[] // Flattened list including subshapes
  totalMainArea: number // Area of main shapes only
  totalCombinedArea: number // All areas including subshapes
  overlapAdjustedArea: number // Total area with overlap corrections
}

interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  shapeValidation?: {
    shapeId: string
    type: ShapeType
    measurements: { [key: string]: number }
    area: number
    isValidShape: boolean
    validationDetails: string[]
    hierarchyValidation?: {
      hasValidParent: boolean
      subshapeCount: number
      overlapIssues: string[]
    }
  }[]
}

interface ShapeAnalysis {
  shapes: DetectedShape[]
  hierarchy: ShapeHierarchy
  scale: {
    pixelsPerMeter: number
    confidence: number
  }
  totalArea: number
  notes: string
  provider: "gemini"
  validation?: ValidationResult
}

// Utility functions for hierarchy processing
function buildShapeHierarchy(shapes: DetectedShape[]): ShapeHierarchy {
  const mainShapes: DetectedShape[] = []
  const allShapes: DetectedShape[] = []

  // Organize shapes by hierarchy
  shapes.forEach((shape) => {
    allShapes.push(shape)
    if (!shape.parentId) {
      mainShapes.push(shape)
    }
  })

  // Attach subshapes to their parents
  mainShapes.forEach((mainShape) => {
    mainShape.subshapes = shapes.filter((s) => s.parentId === mainShape.id)
  })

  const totalMainArea = mainShapes.reduce((sum, shape) => sum + shape.area, 0)
  const totalCombinedArea = allShapes.reduce((sum, shape) => sum + shape.area, 0)

  // Calculate overlap-adjusted area (subtract subshape areas from parent areas)
  let overlapAdjustedArea = totalMainArea
  mainShapes.forEach((mainShape) => {
    if (mainShape.subshapes && mainShape.subshapes.length > 0) {
      const subshapeArea = mainShape.subshapes.reduce((sum, sub) => sum + sub.area, 0)
      // Don't double-count subshape areas
      overlapAdjustedArea -= subshapeArea
    }
  })

  return {
    mainShapes,
    allShapes,
    totalMainArea,
    totalCombinedArea,
    overlapAdjustedArea: Math.max(0, overlapAdjustedArea),
  }
}

function detectOverlaps(shapes: DetectedShape[]): string[] {
  const overlaps: string[] = []

  for (let i = 0; i < shapes.length; i++) {
    for (let j = i + 1; j < shapes.length; j++) {
      const shape1 = shapes[i]
      const shape2 = shapes[j]

      // Simple overlap detection based on coordinate proximity
      const hasOverlap = shape1.coordinates.some((coord1) =>
        shape2.coordinates.some(
          (coord2) => Math.abs(coord1[0] - coord2[0]) < 10 && Math.abs(coord1[1] - coord2[1]) < 10,
        ),
      )

      if (hasOverlap && !shape1.parentId && !shape2.parentId) {
        overlaps.push(`Potential overlap between ${shape1.id} and ${shape2.id}`)
      }
    }
  }

  return overlaps
}

export function validateShapeDetection(shapes: DetectedShape[]): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  const shapeValidation: ValidationResult["shapeValidation"] = []

  if (shapes.length === 0) {
    errors.push("No shapes detected in the survey image")
    return { isValid: false, errors, warnings }
  }

  const overlapIssues = detectOverlaps(shapes)
  if (overlapIssues.length > 0) {
    warnings.push(...overlapIssues)
  }

  shapes.forEach((shape) => {
    const validationDetails: string[] = []
    let isValidShape = true

    const hierarchyValidation = {
      hasValidParent: !shape.parentId || shapes.some((s) => s.id === shape.parentId),
      subshapeCount: shape.subshapes?.length || 0,
      overlapIssues: overlapIssues.filter((issue) => issue.includes(shape.id)),
    }

    if (shape.parentId && !hierarchyValidation.hasValidParent) {
      errors.push(`${shape.id}: Invalid parent reference ${shape.parentId}`)
      isValidShape = false
    }

    switch (shape.type) {
      case "triangle":
        const { a, b, c } = shape.measurements
        if (a && b && c) {
          // Triangle inequality check
          if (a + b <= c || a + c <= b || b + c <= a) {
            isValidShape = false
            validationDetails.push(`Triangle inequality violated: ${a.toFixed(2)} + ${b.toFixed(2)} ≤ ${c.toFixed(2)}`)
          } else {
            validationDetails.push("Triangle inequality satisfied")
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurements: sides a, b, c")
        }
        break

      case "rectangle":
      case "square":
        const { width, height } = shape.measurements
        if (width && height) {
          if (width <= 0 || height <= 0) {
            isValidShape = false
            validationDetails.push("Width and height must be positive")
          } else {
            validationDetails.push("Rectangle measurements valid")
            if (shape.type === "square" && Math.abs(width - height) > 0.1) {
              warnings.push(`${shape.id}: Square has unequal sides (${width.toFixed(2)} × ${height.toFixed(2)})`)
            }
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurements: width, height")
        }
        break

      case "circle":
        const { radius } = shape.measurements
        if (radius) {
          if (radius <= 0) {
            isValidShape = false
            validationDetails.push("Radius must be positive")
          } else {
            validationDetails.push("Circle measurements valid")
          }
        } else {
          isValidShape = false
          validationDetails.push("Missing required measurement: radius")
        }
        break

      case "polygon":
        const sides = Object.values(shape.measurements).filter((val) => val > 0)
        if (sides.length < 3) {
          isValidShape = false
          validationDetails.push("Polygon must have at least 3 sides")
        } else {
          validationDetails.push(`Polygon with ${sides.length} sides detected`)
        }
        break
    }

    // Check for reasonable measurements
    const measurements = Object.values(shape.measurements)
    measurements.forEach((measurement, index) => {
      if (measurement < 0.1) {
        warnings.push(`${shape.id}: Very small measurement (${measurement.toFixed(2)}m) - check scale`)
      } else if (measurement > 500) {
        warnings.push(`${shape.id}: Very large measurement (${measurement.toFixed(2)}m) - check scale`)
      }
    })

    shapeValidation.push({
      shapeId: shape.id,
      type: shape.type,
      measurements: shape.measurements,
      area: shape.area,
      isValidShape,
      validationDetails,
      hierarchyValidation,
    })

    if (!isValidShape) {
      errors.push(`${shape.id}: Invalid ${shape.type} - ${validationDetails.join(", ")}`)
    }
  })

  const isValid = errors.length === 0

  if (isValid && warnings.length === 0) {
    warnings.push("All shapes passed validation checks")
  }

  return {
    isValid,
    errors,
    warnings,
    shapeValidation,
  }
}

export async function analyzeShapesWithGemini(imageData: string): Promise<ShapeAnalysis> {
  const response = await fetch("/api/analyze-shapes-gemini", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ imageData }),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.error || "Failed to analyze with Gemini")
  }

  const result = await response.json()

  const shapesWithAreas = result.data.shapes.map((shape: any) => {
    let area = 0
    let formula = ""

    switch (shape.type) {
      case "triangle":
        const { a, b, c } = shape.measurements
        area = calculateTriangleArea(a, b, c)
        formula = "Heron's Formula: √(s(s-a)(s-b)(s-c))"
        break
      case "rectangle":
        const { width, height } = shape.measurements
        area = calculateRectangleArea(width, height)
        formula = "Rectangle: width × height"
        break
      case "square":
        const { side } = shape.measurements
        area = calculateRectangleArea(side, side)
        formula = "Square: side²"
        break
      case "circle":
        const { radius } = shape.measurements
        area = calculateCircleArea(radius)
        formula = "Circle: π × radius²"
        break
      case "polygon":
        // Use shoelace formula for irregular polygons
        area = calculatePolygonArea(shape.coordinates)
        formula = "Shoelace Formula for irregular polygon"
        break
      default:
        area = shape.area || 0
        formula = "Custom calculation"
    }

    return {
      ...shape,
      area,
      formula,
      isSubshape: !!shape.parentId,
      depth: shape.parentId ? 1 : 0, // Simple depth calculation
      subshapes: [],
    }
  })

  const hierarchy = buildShapeHierarchy(shapesWithAreas)

  const analysisData = {
    ...result.data,
    shapes: shapesWithAreas,
    hierarchy,
    totalArea: hierarchy.overlapAdjustedArea, // Use overlap-adjusted area as primary total
    provider: "gemini" as const,
  }

  const validation = validateShapeDetection(analysisData.shapes)

  return {
    ...analysisData,
    validation,
  }
}

export async function analyzeShapes(imageData: string): Promise<{
  result?: ShapeAnalysis
  error?: string
}> {
  try {
    const result = await analyzeShapesWithGemini(imageData)
    return { result }
  } catch (error: any) {
    const errorMessage = error.message
    if (errorMessage.includes("API key is missing")) {
      return {
        error: "Gemini API key not configured. Please add GOOGLE_GENERATIVE_AI_API_KEY to your environment variables.",
      }
    } else {
      return { error: `Shape analysis failed: ${errorMessage}` }
    }
  }
}
