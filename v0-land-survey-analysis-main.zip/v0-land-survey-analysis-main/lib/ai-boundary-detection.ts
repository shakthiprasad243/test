import { heronsFormulaEnhanced } from "./survey-calculations"

interface BoundaryPoint {
  point: string
  coordinates: [number, number]
  length: number
}

interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  triangleValidation?: {
    triangleId: string
    sides: number[]
    area: number
    isValidTriangle: boolean
    triangleType: string
    validationDetails: string[]
  }[]
}

interface BoundaryAnalysis {
  boundaries: BoundaryPoint[]
  scale: {
    pixelsPerMeter: number
    confidence: number
  }
  totalArea: number
  notes: string
  provider: "gemini"
  validation?: ValidationResult
}

export function validateBoundaryDetection(boundaries: BoundaryPoint[]): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  const triangleValidation: ValidationResult["triangleValidation"] = []

  // Basic validation
  if (boundaries.length < 3) {
    errors.push("Insufficient boundary points: need at least 3 points to form a polygon")
    return { isValid: false, errors, warnings }
  }

  // Extract side lengths for validation
  const sides = boundaries.map((b) => b.length).filter((length) => length > 0)

  if (sides.length < 3) {
    errors.push("Insufficient side measurements: need at least 3 valid side lengths")
    return { isValid: false, errors, warnings }
  }

  // Validate individual triangles if we can form them
  if (boundaries.length >= 3) {
    // For polygons with more than 3 sides, validate triangulation
    const triangles = triangulatePolygonForValidation(boundaries)

    triangles.forEach((triangle, index) => {
      const triangleId = `T${index + 1}`
      const [sideA, sideB, sideC] = triangle.sides

      // Use enhanced Heron's formula for detailed validation
      const heronResult = heronsFormulaEnhanced(sideA, sideB, sideC)

      triangleValidation.push({
        triangleId,
        sides: triangle.sides,
        area: heronResult.area,
        isValidTriangle: heronResult.isValid,
        triangleType: heronResult.triangleType,
        validationDetails: heronResult.validationDetails,
      })

      if (!heronResult.isValid) {
        errors.push(
          `${triangleId}: ${heronResult.error} - sides: ${sideA.toFixed(2)}, ${sideB.toFixed(2)}, ${sideC.toFixed(2)}`,
        )
      } else if (heronResult.triangleType.includes("Degenerate")) {
        warnings.push(`${triangleId}: Triangle appears degenerate (very flat or narrow)`)
      }
    })
  }

  // Check for reasonable measurements (based on typical land survey ranges)
  sides.forEach((side, index) => {
    if (side < 1) {
      warnings.push(
        `Side ${boundaries[index]?.point || index + 1}: Very small measurement (${side.toFixed(2)}m) - check scale`,
      )
    } else if (side > 1000) {
      warnings.push(
        `Side ${boundaries[index]?.point || index + 1}: Very large measurement (${side.toFixed(2)}m) - check scale`,
      )
    }
  })

  // Check for scale consistency
  const avgSideLength = sides.reduce((sum, side) => sum + side, 0) / sides.length
  const sideVariation = Math.max(...sides) / Math.min(...sides)

  if (sideVariation > 10) {
    warnings.push(`High variation in side lengths (${sideVariation.toFixed(1)}x difference) - verify scale accuracy`)
  }

  // Overall validation result
  const isValid = errors.length === 0

  if (isValid && warnings.length === 0) {
    warnings.push("Boundary detection passed all validation checks")
  }

  return {
    isValid,
    errors,
    warnings,
    triangleValidation,
  }
}

function triangulatePolygonForValidation(boundaries: BoundaryPoint[]): { sides: number[] }[] {
  const triangles: { sides: number[] }[] = []

  if (boundaries.length === 3) {
    // Simple triangle
    triangles.push({
      sides: [boundaries[0].length, boundaries[1].length, boundaries[2].length],
    })
  } else if (boundaries.length === 4) {
    // Quadrilateral - split into two triangles
    // This is a simplified approach - in reality we'd need coordinate-based triangulation
    const sides = boundaries.map((b) => b.length)

    // Triangle 1: sides 0, 1, diagonal
    // Triangle 2: sides 2, 3, diagonal
    // For validation purposes, we'll estimate diagonal using coordinate distance if available

    // Simplified: assume we can form valid triangles
    if (sides.length >= 4) {
      triangles.push({
        sides: [sides[0], sides[1], Math.sqrt(sides[0] ** 2 + sides[1] ** 2)], // Rough diagonal estimate
      })
      triangles.push({
        sides: [sides[2], sides[3], Math.sqrt(sides[2] ** 2 + sides[3] ** 2)], // Rough diagonal estimate
      })
    }
  } else {
    // For more complex polygons, create triangles using fan triangulation approach
    const sides = boundaries.map((b) => b.length)
    for (let i = 1; i < sides.length - 1; i++) {
      triangles.push({
        sides: [sides[0], sides[i], sides[i + 1]],
      })
    }
  }

  return triangles
}

export async function analyzeBoundariesWithGemini(imageData: string): Promise<BoundaryAnalysis> {
  const response = await fetch("/api/analyze-boundaries-gemini", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ imageData }),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.error || "Failed to analyze with Gemini")
  }

  const result = await response.json()

  const analysisData = { ...result.data, provider: "gemini" as const }
  const validation = validateBoundaryDetection(analysisData.boundaries)

  return {
    ...analysisData,
    validation,
  }
}

export async function analyzeBoundaries(imageData: string): Promise<{
  result?: BoundaryAnalysis
  error?: string
}> {
  try {
    const result = await analyzeBoundariesWithGemini(imageData)
    return { result }
  } catch (error: any) {
    const errorMessage = error.message
    if (errorMessage.includes("API key is missing")) {
      return {
        error: "Gemini API key not configured. Please add GOOGLE_GENERATIVE_AI_API_KEY to your environment variables.",
      }
    } else {
      return { error: `Analysis failed: ${errorMessage}` }
    }
  }
}
