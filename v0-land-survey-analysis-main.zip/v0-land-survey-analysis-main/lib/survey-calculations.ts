// Mathematical calculations engine for land survey area calculations
// Implements all 12 supported formulas as specified in the requirements

export interface Point {
  x: number
  y: number
}

export interface Triangle {
  vertices: Point[]
  sides?: number[]
  angles?: number[]
}

export interface CalculationResult {
  area: number
  formula: string
  details: string
  isValid: boolean
  error?: string
}

// Enum and interface for better integration with manual triangle calculator
export enum TriangleCalculationMethod {
  HERON = "heron",
  BASE_HEIGHT = "base_height",
  SAS = "sas",
  ASA = "asa",
  EQUILATERAL = "equilateral",
  RIGHT_TRIANGLE = "right_triangle",
  SHOELACE = "shoelace",
  VECTOR_CROSS_PRODUCT = "vector_cross_product",
  CIRCUMRADIUS = "circumradius",
  INRADIUS = "inradius",
  DETERMINANT = "determinant",
  SURVEYING_POLYGON = "surveying_polygon",
}

export interface TriangleInputData {
  sideA?: number
  sideB?: number
  sideC?: number
  base?: number
  height?: number
  angleA?: number
  angleB?: number
  angleC?: number
  points?: Point[]
  circumradius?: number
  inradius?: number
}

// Unified triangle area calculation function for manual calculator
export function calculateTriangleArea(method: TriangleCalculationMethod, data: TriangleInputData): CalculationResult {
  switch (method) {
    case TriangleCalculationMethod.HERON:
      if (!data.sideA || !data.sideB || !data.sideC) {
        return {
          area: 0,
          formula: "Heron's Formula",
          details: "Missing required sides A, B, and C",
          isValid: false,
          error: "Missing required data",
        }
      }
      return heronsFormula(data.sideA, data.sideB, data.sideC)

    case TriangleCalculationMethod.BASE_HEIGHT:
      if (!data.base || !data.height) {
        return {
          area: 0,
          formula: "Base × Height",
          details: "Missing required base and height",
          isValid: false,
          error: "Missing required data",
        }
      }
      return baseHeightFormula(data.base, data.height)

    case TriangleCalculationMethod.SAS:
      if (!data.sideA || !data.sideB || !data.angleC) {
        return {
          area: 0,
          formula: "SAS Formula",
          details: "Missing required sides A, B and included angle C",
          isValid: false,
          error: "Missing required data",
        }
      }
      return sasFormula(data.sideA, data.sideB, data.angleC)

    case TriangleCalculationMethod.ASA:
      if (!data.sideA || !data.angleA || !data.angleB) {
        return {
          area: 0,
          formula: "ASA Formula",
          details: "Missing required side A and angles A, B",
          isValid: false,
          error: "Missing required data",
        }
      }
      return asaFormula(data.sideA, data.angleA, data.angleB)

    case TriangleCalculationMethod.EQUILATERAL:
      if (!data.sideA) {
        return {
          area: 0,
          formula: "Equilateral Triangle",
          details: "Missing required side length",
          isValid: false,
          error: "Missing required data",
        }
      }
      return equilateralFormula(data.sideA)

    case TriangleCalculationMethod.RIGHT_TRIANGLE:
      if (!data.sideA || !data.sideB) {
        return {
          area: 0,
          formula: "Right Triangle",
          details: "Missing required sides A and B",
          isValid: false,
          error: "Missing required data",
        }
      }
      return rightTriangleFormula(data.sideA, data.sideB)

    case TriangleCalculationMethod.SHOELACE:
      if (!data.points || data.points.length < 3) {
        return {
          area: 0,
          formula: "Shoelace Formula",
          details: "Missing required coordinate points",
          isValid: false,
          error: "Missing required data",
        }
      }
      return shoelaceFormula(data.points)

    case TriangleCalculationMethod.VECTOR_CROSS_PRODUCT:
      if (!data.points || data.points.length < 3) {
        return {
          area: 0,
          formula: "Vector Cross Product",
          details: "Missing required 3 coordinate points",
          isValid: false,
          error: "Missing required data",
        }
      }
      return vectorCrossProductFormula(data.points[0], data.points[1], data.points[2])

    case TriangleCalculationMethod.CIRCUMRADIUS:
      if (!data.sideA || !data.sideB || !data.sideC || !data.circumradius) {
        return {
          area: 0,
          formula: "Circumradius Formula",
          details: "Missing required sides A, B, C and circumradius",
          isValid: false,
          error: "Missing required data",
        }
      }
      return circumradiusFormula(data.sideA, data.sideB, data.sideC, data.circumradius)

    case TriangleCalculationMethod.INRADIUS:
      if (!data.sideA || !data.sideB || !data.sideC || !data.inradius) {
        return {
          area: 0,
          formula: "Inradius Formula",
          details: "Missing required sides A, B, C and inradius",
          isValid: false,
          error: "Missing required data",
        }
      }
      return inradiusFormula(data.inradius, data.sideA, data.sideB, data.sideC)

    case TriangleCalculationMethod.DETERMINANT:
      if (!data.points || data.points.length < 3) {
        return {
          area: 0,
          formula: "Determinant Formula",
          details: "Missing required 3 coordinate points",
          isValid: false,
          error: "Missing required data",
        }
      }
      return determinantFormula(data.points[0], data.points[1], data.points[2])

    case TriangleCalculationMethod.SURVEYING_POLYGON:
      if (!data.points || data.points.length < 3) {
        return {
          area: 0,
          formula: "Surveying Polygon Formula",
          details: "Missing required coordinate points",
          isValid: false,
          error: "Insufficient points",
        }
      }
      return surveyingPolygonFormula(data.points)

    default:
      return {
        area: 0,
        formula: "Unknown Method",
        details: "Unsupported calculation method",
        isValid: false,
        error: "Unsupported method",
      }
  }
}

export function heronsFormulaEnhanced(
  a: number,
  b: number,
  c: number,
): CalculationResult & {
  semiPerimeter: number
  triangleType: string
  validationDetails: string[]
} {
  const validationDetails: string[] = []

  // Input validation
  if (a <= 0 || b <= 0 || c <= 0) {
    validationDetails.push("All sides must be positive numbers")
    return {
      area: 0,
      semiPerimeter: 0,
      triangleType: "Invalid",
      formula: "Heron's Formula (Enhanced)",
      details: "Invalid triangle: negative or zero side lengths",
      validationDetails,
      isValid: false,
      error: "Invalid side lengths",
    }
  }

  // Triangle inequality validation with detailed feedback
  const inequalities = [
    { condition: a + b > c, description: `Side A (${a}) + Side B (${b}) = ${a + b} > Side C (${c})` },
    { condition: a + c > b, description: `Side A (${a}) + Side C (${c}) = ${a + c} > Side B (${b})` },
    { condition: b + c > a, description: `Side B (${b}) + Side C (${c}) = ${b + c} > Side A (${a})` },
  ]

  const failedInequalities = inequalities.filter((ineq) => !ineq.condition)

  if (failedInequalities.length > 0) {
    validationDetails.push("Triangle inequality violations:")
    failedInequalities.forEach((ineq) => validationDetails.push(`  ✗ ${ineq.description}`))

    return {
      area: 0,
      semiPerimeter: 0,
      triangleType: "Degenerate",
      formula: "Heron's Formula (Enhanced)",
      details: "Invalid triangle: sides do not satisfy triangle inequality",
      validationDetails,
      isValid: false,
      error: "Triangle inequality violated",
    }
  }

  // All inequalities passed
  inequalities.forEach((ineq) => validationDetails.push(`  ✓ ${ineq.description}`))

  const s = (a + b + c) / 2 // semi-perimeter
  const area = Math.sqrt(s * (s - a) * (s - b) * (s - c))

  // Determine triangle type
  let triangleType = "Scalene"
  if (a === b && b === c) {
    triangleType = "Equilateral"
  } else if (a === b || b === c || a === c) {
    triangleType = "Isosceles"
  }

  // Check if it's a right triangle (using Pythagorean theorem with tolerance)
  const sides = [a, b, c].sort((x, y) => x - y)
  const tolerance = 0.001
  if (Math.abs(sides[0] ** 2 + sides[1] ** 2 - sides[2] ** 2) < tolerance) {
    triangleType += " Right"
  }

  validationDetails.push(`Triangle type: ${triangleType}`)
  validationDetails.push(`Semi-perimeter: ${s.toFixed(4)}`)

  return {
    area,
    semiPerimeter: s,
    triangleType,
    formula: "Heron's Formula (Enhanced)",
    details: `Area = √(${s.toFixed(4)} × ${(s - a).toFixed(4)} × ${(s - b).toFixed(4)} × ${(s - c).toFixed(4)}) = ${area.toFixed(4)}`,
    validationDetails,
    isValid: !isNaN(area) && area > 0,
  }
}

// 1. Heron's Formula (3 sides)
export function heronsFormula(a: number, b: number, c: number): CalculationResult {
  // Validate triangle inequality
  if (a + b <= c || a + c <= b || b + c <= a) {
    return {
      area: 0,
      formula: "Heron's Formula",
      details: "Invalid triangle: sides do not satisfy triangle inequality",
      isValid: false,
      error: "Degenerate triangle",
    }
  }

  const s = (a + b + c) / 2 // semi-perimeter
  const area = Math.sqrt(s * (s - a) * (s - b) * (s - c))

  return {
    area,
    formula: "Heron's Formula",
    details: `Semi-perimeter: ${s.toFixed(2)}, Area = √(${s.toFixed(2)} × ${(s - a).toFixed(2)} × ${(s - b).toFixed(2)} × ${(s - c).toFixed(2)})`,
    isValid: !isNaN(area) && area > 0,
  }
}

// 2. Base × Height
export function baseHeightFormula(base: number, height: number): CalculationResult {
  if (base <= 0 || height <= 0) {
    return {
      area: 0,
      formula: "Base × Height",
      details: "Invalid dimensions: base and height must be positive",
      isValid: false,
      error: "Invalid dimensions",
    }
  }

  const area = 0.5 * base * height

  return {
    area,
    formula: "Base × Height",
    details: `Area = 0.5 × ${base} × ${height}`,
    isValid: true,
  }
}

// 3. SAS (two sides + included angle)
export function sasFormula(a: number, b: number, angleC: number): CalculationResult {
  if (a <= 0 || b <= 0 || angleC <= 0 || angleC >= 180) {
    return {
      area: 0,
      formula: "SAS Formula",
      details: "Invalid inputs: sides must be positive, angle must be between 0° and 180°",
      isValid: false,
      error: "Invalid inputs",
    }
  }

  const angleRadians = (angleC * Math.PI) / 180
  const area = 0.5 * a * b * Math.sin(angleRadians)

  return {
    area,
    formula: "SAS Formula",
    details: `Area = 0.5 × ${a} × ${b} × sin(${angleC}°)`,
    isValid: true,
  }
}

// 4. ASA/AAS (via Law of Sines)
export function asaFormula(side: number, angleA: number, angleB: number): CalculationResult {
  if (side <= 0 || angleA <= 0 || angleB <= 0 || angleA + angleB >= 180) {
    return {
      area: 0,
      formula: "ASA/AAS Formula",
      details: "Invalid inputs: side must be positive, angles must be valid",
      isValid: false,
      error: "Invalid inputs",
    }
  }

  const angleC = 180 - angleA - angleB
  const angleARadians = (angleA * Math.PI) / 180
  const angleBRadians = (angleB * Math.PI) / 180
  const angleCRadians = (angleC * Math.PI) / 180

  // Using Law of Sines to find other sides
  const a = (side * Math.sin(angleARadians)) / Math.sin(angleCRadians)
  const b = (side * Math.sin(angleBRadians)) / Math.sin(angleCRadians)

  const area = 0.5 * a * b * Math.sin(angleCRadians)

  return {
    area,
    formula: "ASA/AAS Formula",
    details: `Using Law of Sines: a=${a.toFixed(2)}, b=${b.toFixed(2)}, C=${angleC}°`,
    isValid: true,
  }
}

// 5. Equilateral triangle formula
export function equilateralFormula(side: number): CalculationResult {
  if (side <= 0) {
    return {
      area: 0,
      formula: "Equilateral Triangle",
      details: "Invalid side length: must be positive",
      isValid: false,
      error: "Invalid side length",
    }
  }

  const area = (Math.sqrt(3) / 4) * side * side

  return {
    area,
    formula: "Equilateral Triangle",
    details: `Area = (√3/4) × ${side}²`,
    isValid: true,
  }
}

// 6. Right triangle formula
export function rightTriangleFormula(a: number, b: number): CalculationResult {
  if (a <= 0 || b <= 0) {
    return {
      area: 0,
      formula: "Right Triangle",
      details: "Invalid side lengths: must be positive",
      isValid: false,
      error: "Invalid side lengths",
    }
  }

  const area = 0.5 * a * b

  return {
    area,
    formula: "Right Triangle",
    details: `Area = 0.5 × ${a} × ${b}`,
    isValid: true,
  }
}

// 7. Shoelace formula (coordinates method for polygons)
export function shoelaceFormula(points: Point[]): CalculationResult {
  if (points.length < 3) {
    return {
      area: 0,
      formula: "Shoelace Formula",
      details: "Invalid polygon: need at least 3 points",
      isValid: false,
      error: "Insufficient points",
    }
  }

  let area = 0
  const n = points.length

  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n
    area += points[i].x * points[j].y
    area -= points[j].x * points[i].y
  }

  area = Math.abs(area) / 2

  return {
    area,
    formula: "Shoelace Formula",
    details: `Calculated from ${n} coordinate points`,
    isValid: area > 0,
  }
}

// 8. Vector cross product formula
export function vectorCrossProductFormula(p1: Point, p2: Point, p3: Point): CalculationResult {
  // Vectors from p1 to p2 and p1 to p3
  const v1 = { x: p2.x - p1.x, y: p2.y - p1.y }
  const v2 = { x: p3.x - p1.x, y: p3.y - p1.y }

  // Cross product magnitude
  const crossProduct = Math.abs(v1.x * v2.y - v1.y * v2.x)
  const area = crossProduct / 2

  return {
    area,
    formula: "Vector Cross Product",
    details: `Cross product: |${v1.x.toFixed(2)}×${v2.y.toFixed(2)} - ${v1.y.toFixed(2)}×${v2.x.toFixed(2)}| / 2`,
    isValid: area > 0,
  }
}

// 9. Circumradius formula → A = abc/(4R)
export function circumradiusFormula(a: number, b: number, c: number, R: number): CalculationResult {
  if (a <= 0 || b <= 0 || c <= 0 || R <= 0) {
    return {
      area: 0,
      formula: "Circumradius Formula",
      details: "Invalid inputs: all values must be positive",
      isValid: false,
      error: "Invalid inputs",
    }
  }

  const area = (a * b * c) / (4 * R)

  return {
    area,
    formula: "Circumradius Formula",
    details: `Area = (${a} × ${b} × ${c}) / (4 × ${R})`,
    isValid: true,
  }
}

// 10. Inradius formula → A = r × s
export function inradiusFormula(r: number, a: number, b: number, c: number): CalculationResult {
  if (r <= 0 || a <= 0 || b <= 0 || c <= 0) {
    return {
      area: 0,
      formula: "Inradius Formula",
      details: "Invalid inputs: all values must be positive",
      isValid: false,
      error: "Invalid inputs",
    }
  }

  const s = (a + b + c) / 2 // semi-perimeter
  const area = r * s

  return {
    area,
    formula: "Inradius Formula",
    details: `Area = ${r} × ${s.toFixed(2)} (semi-perimeter)`,
    isValid: true,
  }
}

// 11. Determinant formula (matrix shoelace form)
export function determinantFormula(p1: Point, p2: Point, p3: Point): CalculationResult {
  const matrix = [
    [p1.x, p1.y, 1],
    [p2.x, p2.y, 1],
    [p3.x, p3.y, 1],
  ]

  // Calculate determinant
  const det =
    matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1]) -
    matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0]) +
    matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])

  const area = Math.abs(det) / 2

  return {
    area,
    formula: "Determinant Formula",
    details: `Matrix determinant: ${det.toFixed(2)}, Area = |det| / 2`,
    isValid: area > 0,
  }
}

// 12. Surveying/Polygon extension of shoelace
export function surveyingPolygonFormula(points: Point[], bearings?: number[]): CalculationResult {
  if (points.length < 3) {
    return {
      area: 0,
      formula: "Surveying Polygon Formula",
      details: "Invalid polygon: need at least 3 points",
      isValid: false,
      error: "Insufficient points",
    }
  }

  // Use enhanced shoelace with surveying considerations
  let area = 0
  let perimeter = 0
  const n = points.length

  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n

    // Shoelace calculation
    area += points[i].x * points[j].y
    area -= points[j].x * points[i].y

    // Calculate perimeter for surveying context
    const dx = points[j].x - points[i].x
    const dy = points[j].y - points[i].y
    perimeter += Math.sqrt(dx * dx + dy * dy)
  }

  area = Math.abs(area) / 2

  return {
    area,
    formula: "Surveying Polygon Formula",
    details: `Polygon with ${n} vertices, perimeter: ${perimeter.toFixed(2)}`,
    isValid: area > 0,
  }
}

// Auto-select best formula based on available data
export function autoSelectFormula(data: {
  points?: Point[]
  sides?: number[]
  angles?: number[]
  circumradius?: number
  inradius?: number
}): CalculationResult {
  const { points, sides, angles, circumradius, inradius } = data

  // Priority order based on data availability and accuracy

  // If we have coordinates, use shoelace (most accurate)
  if (points && points.length >= 3) {
    return shoelaceFormula(points)
  }

  // If we have 3 sides, use Heron's formula
  if (sides && sides.length === 3) {
    return heronsFormula(sides[0], sides[1], sides[2])
  }

  // If we have 2 sides and included angle, use SAS
  if (sides && sides.length === 2 && angles && angles.length >= 1) {
    return sasFormula(sides[0], sides[1], angles[0])
  }

  // If we have inradius and sides, use inradius formula
  if (inradius && sides && sides.length === 3) {
    return inradiusFormula(inradius, sides[0], sides[1], sides[2])
  }

  // If we have circumradius and sides, use circumradius formula
  if (circumradius && sides && sides.length === 3) {
    return circumradiusFormula(sides[0], sides[1], sides[2], circumradius)
  }

  // If we have one side and two angles, use ASA
  if (sides && sides.length === 1 && angles && angles.length >= 2) {
    return asaFormula(sides[0], angles[0], angles[1])
  }

  return {
    area: 0,
    formula: "Auto-Select",
    details: "Insufficient data for calculation",
    isValid: false,
    error: "Insufficient data",
  }
}

// Triangulate polygon using Delaunay-like approach (simplified)
export function triangulatePolygon(points: Point[]): Triangle[] {
  if (points.length < 3) return []
  if (points.length === 3) return [{ vertices: points }]

  const triangles: Triangle[] = []

  // Simple fan triangulation from first vertex
  for (let i = 1; i < points.length - 1; i++) {
    triangles.push({
      vertices: [points[0], points[i], points[i + 1]],
    })
  }

  return triangles
}

// Calculate total area from multiple triangles
export function calculateTotalArea(triangles: Triangle[]): {
  triangleResults: CalculationResult[]
  totalArea: number
  validTriangles: number
} {
  const triangleResults: CalculationResult[] = []
  let totalArea = 0
  let validTriangles = 0

  triangles.forEach((triangle) => {
    const result = shoelaceFormula(triangle.vertices)
    triangleResults.push(result)

    if (result.isValid) {
      totalArea += result.area
      validTriangles++
    }
  })

  return {
    triangleResults,
    totalArea,
    validTriangles,
  }
}

// Shape-specific calculation functions for efficient area computation
export function calculateTriangleAreaEnhanced(a: number, b: number, c: number): number {
  const result = heronsFormulaEnhanced(a, b, c)
  return result.isValid ? result.area : 0
}

export function calculateRectangleArea(width: number, height: number): number {
  if (width <= 0 || height <= 0) return 0
  return width * height
}

export function calculateCircleArea(radius: number): number {
  if (radius <= 0) return 0
  return Math.PI * radius * radius
}

export function calculatePolygonArea(coordinates: [number, number][]): number {
  if (coordinates.length < 3) return 0

  const points: Point[] = coordinates.map(([x, y]) => ({ x, y }))
  const result = shoelaceFormula(points)
  return result.isValid ? result.area : 0
}

export function calculateTrapezoidArea(base1: number, base2: number, height: number): number {
  if (base1 <= 0 || base2 <= 0 || height <= 0) return 0
  return 0.5 * (base1 + base2) * height
}

export function calculateParallelogramArea(base: number, height: number): number {
  if (base <= 0 || height <= 0) return 0
  return base * height
}
