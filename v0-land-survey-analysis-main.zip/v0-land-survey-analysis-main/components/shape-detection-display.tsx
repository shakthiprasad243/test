"use client"
import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, EyeOff, Download, RotateCcw, Brain, AlertCircle, CheckCircle, Shapes } from "lucide-react"
import { analyzeShapes, type ShapeType } from "@/lib/ai-shape-detection"

interface DetectedShape {
  id: string
  type: ShapeType
  coordinates: [number, number][]
  measurements: { [key: string]: number }
  area: number
  confidence: number
  formula: string
}

interface ShapeDetectionDisplayProps {
  image: string
  shapes: DetectedShape[]
  onShapeUpdate?: (shapes: DetectedShape[]) => void
}

export function ShapeDetectionDisplay({ image, shapes, onShapeUpdate }: ShapeDetectionDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imageRef = useRef<HTMLImageElement>(null)
  const [showShapes, setShowShapes] = useState(true)
  const [showLabels, setShowLabels] = useState(true)
  const [showMeasurements, setShowMeasurements] = useState(false)
  const [shapeOpacity, setShapeOpacity] = useState([80])
  const [isProcessing, setIsProcessing] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<any>(null)
  const [analysisError, setAnalysisError] = useState<string | null>(null)

  useEffect(() => {
    if (imageLoaded && canvasRef.current) {
      drawShapes()
    }
  }, [imageLoaded, showShapes, showLabels, showMeasurements, shapeOpacity])

  const handleImageLoad = () => {
    setImageLoaded(true)
  }

  const drawShapes = () => {
    const canvas = canvasRef.current
    const img = imageRef.current
    if (!canvas || !img) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size to match image
    canvas.width = img.naturalWidth
    canvas.height = img.naturalHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (!showShapes) return

    // Color scheme for different shape types
    const shapeColors = {
      triangle: "rgba(99, 102, 241, ",
      rectangle: "rgba(34, 197, 94, ",
      square: "rgba(168, 85, 247, ",
      circle: "rgba(239, 68, 68, ",
      polygon: "rgba(245, 158, 11, ",
      trapezoid: "rgba(20, 184, 166, ",
      parallelogram: "rgba(236, 72, 153, ",
    }

    shapes.forEach((shape, index) => {
      const baseColor = shapeColors[shape.type] || "rgba(156, 163, 175, "
      const opacity = shapeOpacity[0] / 100

      ctx.strokeStyle = baseColor + opacity + ")"
      ctx.fillStyle = baseColor + opacity * 0.3 + ")"
      ctx.lineWidth = 3

      // Draw shape based on type
      if (shape.type === "circle") {
        // Draw circle
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length
        const radius = shape.measurements.radius || 50

        ctx.beginPath()
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI)
        ctx.fill()
        ctx.stroke()
      } else {
        // Draw polygon shapes
        ctx.beginPath()
        shape.coordinates.forEach((coord, coordIndex) => {
          const [x, y] = coord
          if (coordIndex === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        })
        ctx.closePath()
        ctx.fill()
        ctx.stroke()
      }

      // Draw vertices
      shape.coordinates.forEach((coord) => {
        const [x, y] = coord
        ctx.beginPath()
        ctx.arc(x, y, 4, 0, 2 * Math.PI)
        ctx.fillStyle = "white"
        ctx.fill()
        ctx.strokeStyle = baseColor + opacity + ")"
        ctx.lineWidth = 2
        ctx.stroke()
      })

      // Draw shape label
      if (showLabels) {
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length

        ctx.fillStyle = "white"
        ctx.fillRect(centerX - 25, centerY - 15, 50, 30)
        ctx.strokeStyle = baseColor + opacity + ")"
        ctx.lineWidth = 1
        ctx.strokeRect(centerX - 25, centerY - 15, 50, 30)

        ctx.fillStyle = baseColor + "1)"
        ctx.font = "bold 10px sans-serif"
        ctx.textAlign = "center"
        ctx.fillText(shape.id, centerX, centerY - 5)
        ctx.font = "8px sans-serif"
        ctx.fillText(shape.type.toUpperCase(), centerX, centerY + 8)
      }

      // Draw measurements
      if (showMeasurements) {
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length

        ctx.fillStyle = "rgba(0, 0, 0, 0.8)"
        ctx.fillRect(centerX + 30, centerY - 20, 80, 40)
        ctx.fillStyle = "white"
        ctx.font = "10px sans-serif"
        ctx.textAlign = "left"
        ctx.fillText(`Area: ${shape.area.toFixed(1)}m²`, centerX + 35, centerY - 5)
        ctx.fillText(`Formula: ${shape.formula.split(":")[0]}`, centerX + 35, centerY + 10)
      }
    })
  }

  const performAIShapeDetection = async () => {
    if (!image) {
      setAnalysisError("No image available for analysis")
      return
    }

    setIsProcessing(true)
    setAnalysisError(null)

    try {
      console.log("[v0] Starting AI shape detection with Gemini")

      const { result, error } = await analyzeShapes(image)

      if (result) {
        console.log("[v0] AI shape analysis successful:", result)
        setAnalysisResult(result)
        onShapeUpdate?.(result.shapes)
      } else if (error) {
        setAnalysisError(error)
      }
    } catch (error) {
      console.error("[v0] AI shape detection error:", error)
      setAnalysisError(error instanceof Error ? error.message : "Unknown error occurred")
    } finally {
      setIsProcessing(false)
    }
  }

  const downloadOverlay = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = "shape-overlay.png"
    link.href = canvas.toDataURL()
    link.click()
  }

  const resetDetection = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
    }
    onShapeUpdate?.([])
    setAnalysisResult(null)
    setAnalysisError(null)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Shapes className="w-5 h-5" />
            AI Shape Detection & Area Calculation
          </span>
          <div className="flex items-center gap-2">
            <Badge variant={shapes.length > 0 ? "default" : "secondary"}>{shapes.length} shapes detected</Badge>
            <Button
              onClick={performAIShapeDetection}
              disabled={isProcessing || !image}
              className="bg-secondary hover:bg-secondary/90"
            >
              <Brain className="w-4 h-4 mr-2" />
              {isProcessing ? "Analyzing..." : "AI Detect Shapes"}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {analysisError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div>{analysisError}</div>
                {analysisError.includes("API key") && (
                  <div className="text-sm">
                    <strong>Suggestion:</strong> Add your GOOGLE_GENERATIVE_AI_API_KEY to the project environment
                    variables.
                  </div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {analysisResult && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div>Shape analysis completed successfully with Gemini!</div>
                <div className="text-sm">
                  <strong>Results:</strong> {analysisResult.shapes.length} shapes detected,
                  {analysisResult.totalArea.toFixed(1)}m² total area (confidence:{" "}
                  {(analysisResult.scale.confidence * 100).toFixed(0)}%)
                </div>
                {analysisResult.notes && (
                  <div className="text-sm text-muted-foreground">
                    <strong>Notes:</strong> {analysisResult.notes}
                  </div>
                )}
                {analysisResult.validation && analysisResult.validation.errors.length > 0 && (
                  <div className="text-sm text-red-600">
                    <strong>Validation Issues:</strong> {analysisResult.validation.errors.join(", ")}
                  </div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-4 p-3 bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <Switch id="show-shapes" checked={showShapes} onCheckedChange={setShowShapes} />
            <Label htmlFor="show-shapes" className="flex items-center gap-1">
              {showShapes ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              Shapes
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="show-labels" checked={showLabels} onCheckedChange={setShowLabels} />
            <Label htmlFor="show-labels">Labels</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="show-measurements" checked={showMeasurements} onCheckedChange={setShowMeasurements} />
            <Label htmlFor="show-measurements">Measurements</Label>
          </div>

          <div className="flex items-center space-x-2 min-w-32">
            <Label htmlFor="opacity">Opacity</Label>
            <Slider
              id="opacity"
              min={10}
              max={100}
              step={10}
              value={shapeOpacity}
              onValueChange={setShapeOpacity}
              className="flex-1"
            />
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <Button variant="outline" size="sm" onClick={downloadOverlay}>
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
            <Button variant="outline" size="sm" onClick={resetDetection}>
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset
            </Button>
          </div>
        </div>

        {/* Image with Overlay */}
        <div className="relative border rounded-lg overflow-hidden bg-muted">
          <img
            ref={imageRef}
            src={image || "/placeholder.svg"}
            alt="Land plot with shape detection"
            className="w-full h-auto"
            onLoad={handleImageLoad}
          />
          <canvas
            ref={canvasRef}
            className="absolute top-0 left-0 w-full h-full pointer-events-none"
            style={{ mixBlendMode: "multiply" }}
          />

          {isProcessing && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <div className="bg-white rounded-lg p-4 flex items-center gap-3">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-secondary"></div>
                <span className="font-medium">Analyzing shapes with Gemini...</span>
              </div>
            </div>
          )}
        </div>

        {/* Shape Detection Info */}
        {shapes.length > 0 && (
          <div className="space-y-4">
            <h4 className="font-semibold">Detected Shapes</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {shapes.map((shape, index) => (
                <div key={index} className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-bold text-secondary text-lg">{shape.id}</div>
                    <Badge variant="outline">{shape.type}</Badge>
                  </div>
                  <div className="space-y-1 text-sm">
                    <div>
                      <strong>Area:</strong> {shape.area.toFixed(2)}m²
                    </div>
                    <div>
                      <strong>Formula:</strong> {shape.formula}
                    </div>
                    <div>
                      <strong>Confidence:</strong> {(shape.confidence * 100).toFixed(0)}%
                    </div>
                    {Object.entries(shape.measurements).map(([key, value]) => (
                      <div key={key}>
                        <strong>{key}:</strong> {value.toFixed(2)}m
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3 bg-primary/10 rounded-lg">
              <div className="font-semibold text-primary">
                Total Area: {shapes.reduce((sum, shape) => sum + shape.area, 0).toFixed(2)}m²
              </div>
              <div className="text-sm text-muted-foreground">
                ({(shapes.reduce((sum, shape) => sum + shape.area, 0) / 4047).toFixed(4)} acres)
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
