"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectLabel,
  SelectSeparator,
  SelectGroup,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowRightLeft, Calculator, Copy, CheckCircle, Info } from "lucide-react"
import { UnitConverter, AREA_UNITS, ACRE_CONVERSIONS, type ConversionResult } from "@/lib/unit-conversions"

interface UnitConversionPanelProps {
  initialValue?: number
  initialUnit?: string
  onConversionUpdate?: (value: number, unit: string, acres: number) => void
}

export function UnitConversionPanel({
  initialValue = 0,
  initialUnit = "sq_ft",
  onConversionUpdate,
}: UnitConversionPanelProps) {
  const [inputValue, setInputValue] = useState(initialValue.toString())
  const [fromUnit, setFromUnit] = useState(initialUnit)
  const [toUnit, setToUnit] = useState("acre")
  const [conversions, setConversions] = useState<Record<string, ConversionResult>>({})
  const [acreConversion, setAcreConversion] = useState<ConversionResult | null>(null)
  const [copiedUnit, setCopiedUnit] = useState<string | null>(null)

  const unitCategories = UnitConverter.getUnitsByCategory()

  useEffect(() => {
    if (inputValue && !isNaN(Number.parseFloat(inputValue))) {
      const value = Number.parseFloat(inputValue)
      const allConversions = UnitConverter.getAllConversions(value, fromUnit)
      const acres = UnitConverter.toAcres(value, fromUnit)

      setConversions(allConversions)
      setAcreConversion(acres)

      onConversionUpdate?.(value, fromUnit, acres.value)
    } else {
      setConversions({})
      setAcreConversion(null)
    }
  }, [inputValue, fromUnit, onConversionUpdate])

  const handleSwapUnits = () => {
    const temp = fromUnit
    setFromUnit(toUnit)
    setToUnit(temp)

    // Update input value with converted value
    if (conversions[toUnit]) {
      setInputValue(conversions[toUnit].value.toString())
    }
  }

  const copyToClipboard = async (text: string, unit: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedUnit(unit)
      setTimeout(() => setCopiedUnit(null), 2000)
    } catch (error) {
      console.error("Failed to copy:", error)
    }
  }

  const renderUnitOptions = () => {
    return (
      <>
        <SelectGroup>
          <SelectLabel>Metric</SelectLabel>
          {unitCategories.metric.map((unit: any) => (
            <SelectItem key={unit.name} value={unit.name}>
              {AREA_UNITS[unit.name].name} ({AREA_UNITS[unit.name].symbol})
            </SelectItem>
          ))}
        </SelectGroup>
        <SelectSeparator />
        <SelectGroup>
          <SelectLabel>Imperial</SelectLabel>
          {unitCategories.imperial.map((unit: any) => (
            <SelectItem key={unit.name} value={unit.name}>
              {AREA_UNITS[unit.name].name} ({AREA_UNITS[unit.name].symbol})
            </SelectItem>
          ))}
        </SelectGroup>
        <SelectSeparator />
        <SelectGroup>
          <SelectLabel>Survey</SelectLabel>
          {unitCategories.survey.map((unit: any) => (
            <SelectItem key={unit.name} value={unit.name}>
              {AREA_UNITS[unit.name].name} ({AREA_UNITS[unit.name].symbol})
            </SelectItem>
          ))}
        </SelectGroup>
      </>
    )
  }

  const renderConversionGrid = (category: "metric" | "imperial" | "survey") => {
    const categoryUnits = unitCategories[category]

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {categoryUnits.map((unit: any) => {
          const conversion = conversions[unit.name]
          if (!conversion) return null

          return (
            <div key={unit.name} className="p-3 bg-muted rounded-lg">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="font-medium text-sm">{AREA_UNITS[unit.name].name}</div>
                  <div className="text-lg font-bold text-secondary">{conversion.formatted}</div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(conversion.formatted, unit.name)}
                  className="ml-2"
                >
                  {copiedUnit === unit.name ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Unit Conversion System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Input Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="space-y-2">
            <Label htmlFor="input-value">Value</Label>
            <Input
              id="input-value"
              type="number"
              placeholder="Enter area value"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="from-unit">From Unit</Label>
            <Select value={fromUnit} onValueChange={setFromUnit}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>{renderUnitOptions()}</SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleSwapUnits} className="flex-shrink-0 bg-transparent">
              <ArrowRightLeft className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Acre Conversion Highlight */}
        {acreConversion && (
          <Card className="bg-secondary/10 border-secondary/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">Converted to Acres</div>
                  <div className="text-2xl font-bold text-secondary">{acreConversion.formatted}</div>
                </div>
                <Badge variant="secondary">Primary Result</Badge>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Conversion Results */}
        {Object.keys(conversions).length > 0 && (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All Units</TabsTrigger>
              <TabsTrigger value="metric">Metric</TabsTrigger>
              <TabsTrigger value="imperial">Imperial</TabsTrigger>
              <TabsTrigger value="survey">Survey</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h4 className="font-medium mb-3 text-green-700 dark:text-green-300">Metric Units</h4>
                  {renderConversionGrid("metric")}
                </div>
                <div>
                  <h4 className="font-medium mb-3 text-blue-700 dark:text-blue-300">Imperial Units</h4>
                  {renderConversionGrid("imperial")}
                </div>
                <div>
                  <h4 className="font-medium mb-3 text-orange-700 dark:text-orange-300">Survey Units</h4>
                  {renderConversionGrid("survey")}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="metric">{renderConversionGrid("metric")}</TabsContent>

            <TabsContent value="imperial">{renderConversionGrid("imperial")}</TabsContent>

            <TabsContent value="survey">{renderConversionGrid("survey")}</TabsContent>
          </Tabs>
        )}

        {/* Acre Conversion Reference */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Acre Conversion Reference</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-1">
                  <div>
                    <strong>1 acre equals:</strong>
                  </div>
                  <div>• {ACRE_CONVERSIONS.SQ_FEET.toLocaleString()} square feet</div>
                  <div>• {ACRE_CONVERSIONS.SQ_INCHES.toLocaleString()} square inches</div>
                  <div>• {ACRE_CONVERSIONS.SQ_METERS.toLocaleString()} square meters</div>
                </div>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  )
}
