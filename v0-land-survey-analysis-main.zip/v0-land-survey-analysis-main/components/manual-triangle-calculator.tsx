"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Calculator, Triangle, AlertTriangle } from "lucide-react"
import { calculateTriangleArea, TriangleCalculationMethod } from "@/lib/survey-calculations"

interface TriangleInput {
  id: string
  name: string
  sideA: string
  sideB: string
  sideC: string
}

interface CalculationResult {
  triangleId: string
  area: number
  isValid: boolean
  error?: string
}

export function ManualTriangleCalculator() {
  const [triangles, setTriangles] = useState<TriangleInput[]>([
    { id: "T1", name: "Triangle 1", sideA: "", sideB: "", sideC: "" },
  ])
  const [unit, setUnit] = useState<string>("feet")
  const [results, setResults] = useState<CalculationResult[]>([])
  const [totalArea, setTotalArea] = useState<number>(0)
  const [isCalculating, setIsCalculating] = useState(false)

  const addTriangle = () => {
    const newId = `T${triangles.length + 1}`
    setTriangles([
      ...triangles,
      {
        id: newId,
        name: `Triangle ${triangles.length + 1}`,
        sideA: "",
        sideB: "",
        sideC: "",
      },
    ])
  }

  const removeTriangle = (id: string) => {
    if (triangles.length > 1) {
      setTriangles(triangles.filter((t) => t.id !== id))
    }
  }

  const updateTriangle = (id: string, field: keyof TriangleInput, value: string) => {
    setTriangles(triangles.map((t) => (t.id === id ? { ...t, [field]: value } : t)))
  }

  const calculateAllAreas = () => {
    setIsCalculating(true)
    const calculationResults: CalculationResult[] = []
    let total = 0

    triangles.forEach((triangle) => {
      const a = Number.parseFloat(triangle.sideA)
      const b = Number.parseFloat(triangle.sideB)
      const c = Number.parseFloat(triangle.sideC)

      if (isNaN(a) || isNaN(b) || isNaN(c) || a <= 0 || b <= 0 || c <= 0) {
        calculationResults.push({
          triangleId: triangle.id,
          area: 0,
          isValid: false,
          error: "Invalid side lengths. All sides must be positive numbers.",
        })
        return
      }

      // Check triangle inequality
      if (a + b <= c || a + c <= b || b + c <= a) {
        calculationResults.push({
          triangleId: triangle.id,
          area: 0,
          isValid: false,
          error: "Triangle inequality violated. The sum of any two sides must be greater than the third side.",
        })
        return
      }

      try {
        const result = calculateTriangleArea(TriangleCalculationMethod.HERON, { sideA: a, sideB: b, sideC: c })

        calculationResults.push({
          triangleId: triangle.id,
          area: result.area,
          isValid: true,
        })
        total += result.area
      } catch (error) {
        calculationResults.push({
          triangleId: triangle.id,
          area: 0,
          isValid: false,
          error: error instanceof Error ? error.message : "Calculation failed",
        })
      }
    })

    setResults(calculationResults)
    setTotalArea(total)
    setIsCalculating(false)
  }

  const convertToAcres = (areaInSquareFeet: number): number => {
    return areaInSquareFeet / 43560 // 1 acre = 43,560 square feet
  }

  const clearAll = () => {
    setTriangles([{ id: "T1", name: "Triangle 1", sideA: "", sideB: "", sideC: "" }])
    setResults([])
    setTotalArea(0)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Triangle className="h-5 w-5" />
          Manual Triangle Calculator
        </CardTitle>
        <CardDescription>Calculate polygon area by dividing it into triangles using Heron's formula</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Unit Selection */}
        <div className="flex items-center gap-4">
          <Label htmlFor="unit-select">Measurement Unit:</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="feet">Feet</SelectItem>
              <SelectItem value="meters">Meters</SelectItem>
              <SelectItem value="yards">Yards</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Triangle Inputs */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Triangle Measurements</h3>
            <div className="flex gap-2">
              <Button onClick={addTriangle} variant="outline" size="sm">
                Add Triangle
              </Button>
              <Button onClick={clearAll} variant="outline" size="sm">
                Clear All
              </Button>
            </div>
          </div>

          {triangles.map((triangle, index) => (
            <Card key={triangle.id} className="p-4">
              <div className="flex items-center justify-between mb-3">
                <Label className="font-medium">{triangle.name}</Label>
                {triangles.length > 1 && (
                  <Button
                    onClick={() => removeTriangle(triangle.id)}
                    variant="ghost"
                    size="sm"
                    className="text-red-500 hover:text-red-700"
                  >
                    Remove
                  </Button>
                )}
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label htmlFor={`${triangle.id}-a`}>Side A ({unit})</Label>
                  <Input
                    id={`${triangle.id}-a`}
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={triangle.sideA}
                    onChange={(e) => updateTriangle(triangle.id, "sideA", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor={`${triangle.id}-b`}>Side B ({unit})</Label>
                  <Input
                    id={`${triangle.id}-b`}
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={triangle.sideB}
                    onChange={(e) => updateTriangle(triangle.id, "sideB", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor={`${triangle.id}-c`}>Side C ({unit})</Label>
                  <Input
                    id={`${triangle.id}-c`}
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={triangle.sideC}
                    onChange={(e) => updateTriangle(triangle.id, "sideC", e.target.value)}
                  />
                </div>
              </div>

              {/* Show result for this triangle */}
              {results.find((r) => r.triangleId === triangle.id) && (
                <div className="mt-3 pt-3 border-t">
                  {results.find((r) => r.triangleId === triangle.id)?.isValid ? (
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">
                        Area: {results.find((r) => r.triangleId === triangle.id)?.area.toFixed(2)} sq {unit}
                      </Badge>
                    </div>
                  ) : (
                    <Alert className="border-red-200 bg-red-50">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      <AlertDescription className="text-red-700">
                        {results.find((r) => r.triangleId === triangle.id)?.error}
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Calculate Button */}
        <Button onClick={calculateAllAreas} disabled={isCalculating} className="w-full" size="lg">
          <Calculator className="h-4 w-4 mr-2" />
          {isCalculating ? "Calculating..." : "Calculate Total Area"}
        </Button>

        {/* Results Summary */}
        {results.length > 0 && (
          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-800">Calculation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Valid Triangles:</span>
                  <span className="font-medium">
                    {results.filter((r) => r.isValid).length} of {results.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Total Area:</span>
                  <span className="font-medium">
                    {totalArea.toFixed(2)} sq {unit}
                  </span>
                </div>
                {unit === "feet" && (
                  <div className="flex justify-between text-lg font-semibold text-green-700">
                    <span>Total Area (Acres):</span>
                    <span>{convertToAcres(totalArea).toFixed(4)} acres</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  )
}
