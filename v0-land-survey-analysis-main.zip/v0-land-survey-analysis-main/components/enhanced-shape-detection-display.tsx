"use client"
import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Eye,
  EyeOff,
  Download,
  RotateCcw,
  Brain,
  AlertCircle,
  CheckCircle,
  Shapes,
  Cpu,
  Zap,
  FileText,
  BarChart3,
  Layers,
} from "lucide-react"
import { analyzeShapes, type ShapeType } from "@/lib/enhanced-shape-detection"

interface DetectedShape {
  id: string
  type: ShapeType
  coordinates: [number, number][]
  measurements: { [key: string]: number }
  area: number
  confidence: number
  formula: string
  parentId?: string
  subshapes?: DetectedShape[]
  isSubshape: boolean
  depth: number
  extractedText?: string[]
  boundingBox?: {
    x: number
    y: number
    width: number
    height: number
  }
  processingMethod: "ai" | "cv" | "hybrid"
}

interface EnhancedShapeDetectionDisplayProps {
  image: string
  shapes: DetectedShape[]
  onShapeUpdate?: (shapes: DetectedShape[]) => void
}

export function EnhancedShapeDetectionDisplay({ image, shapes, onShapeUpdate }: EnhancedShapeDetectionDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imageRef = useRef<HTMLImageElement>(null)
  const [showShapes, setShowShapes] = useState(true)
  const [showLabels, setShowLabels] = useState(true)
  const [showMeasurements, setShowMeasurements] = useState(false)
  const [showSubshapes, setShowSubshapes] = useState(true)
  const [showBoundingBoxes, setShowBoundingBoxes] = useState(false)
  const [showExtractedText, setShowExtractedText] = useState(false)
  const [shapeOpacity, setShapeOpacity] = useState([80])
  const [analysisMethod, setAnalysisMethod] = useState<"hybrid" | "ai" | "cv">("hybrid")
  const [isProcessing, setIsProcessing] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<any>(null)
  const [analysisError, setAnalysisError] = useState<string | null>(null)
  const [processingStage, setProcessingStage] = useState<string>("")

  useEffect(() => {
    if (imageLoaded && canvasRef.current) {
      drawShapes()
    }
  }, [imageLoaded, showShapes, showLabels, showMeasurements, showSubshapes, showBoundingBoxes, shapeOpacity])

  const handleImageLoad = () => {
    setImageLoaded(true)
  }

  const drawShapes = () => {
    const canvas = canvasRef.current
    const img = imageRef.current
    if (!canvas || !img) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size to match image
    canvas.width = img.naturalWidth
    canvas.height = img.naturalHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (!showShapes) return

    const shapeColors = {
      triangle: "rgba(99, 102, 241, ",
      rectangle: "rgba(34, 197, 94, ",
      square: "rgba(168, 85, 247, ",
      circle: "rgba(239, 68, 68, ",
      polygon: "rgba(245, 158, 11, ",
      trapezoid: "rgba(20, 184, 166, ",
      parallelogram: "rgba(236, 72, 153, ",
      line: "rgba(156, 163, 175, ",
    }

    const methodColors = {
      ai: "rgba(59, 130, 246, ",
      cv: "rgba(16, 185, 129, ",
      hybrid: "rgba(147, 51, 234, ",
    }

    shapes.forEach((shape, index) => {
      if (shape.isSubshape && !showSubshapes) return

      const baseColor = shapeColors[shape.type] || "rgba(156, 163, 175, "
      const methodColor = methodColors[shape.processingMethod] || baseColor
      const opacity = shapeOpacity[0] / 100

      ctx.strokeStyle = methodColor + opacity + ")"
      ctx.fillStyle = baseColor + opacity * 0.3 + ")"
      ctx.lineWidth = shape.isSubshape ? 2 : 3

      if (shape.isSubshape) {
        ctx.setLineDash([5, 5])
      } else {
        ctx.setLineDash([])
      }

      if (showBoundingBoxes && shape.boundingBox) {
        ctx.strokeStyle = "rgba(255, 0, 0, 0.5)"
        ctx.lineWidth = 1
        ctx.setLineDash([3, 3])
        ctx.strokeRect(shape.boundingBox.x, shape.boundingBox.y, shape.boundingBox.width, shape.boundingBox.height)
        ctx.setLineDash([])
      }

      // Draw shape based on type
      if (shape.type === "circle") {
        // Draw circle
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length
        const radius = shape.measurements.radius || 50

        ctx.beginPath()
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI)
        ctx.fill()
        ctx.stroke()
      } else {
        // Draw polygon shapes
        ctx.beginPath()
        shape.coordinates.forEach((coord, coordIndex) => {
          const [x, y] = coord
          if (coordIndex === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        })
        ctx.closePath()
        ctx.fill()
        ctx.stroke()
      }

      // Draw vertices
      shape.coordinates.forEach((coord) => {
        const [x, y] = coord
        ctx.beginPath()
        ctx.arc(x, y, shape.isSubshape ? 3 : 4, 0, 2 * Math.PI)
        ctx.fillStyle = "white"
        ctx.fill()
        ctx.strokeStyle = methodColor + opacity + ")"
        ctx.lineWidth = 2
        ctx.stroke()
      })

      if (showLabels) {
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length

        const labelWidth = shape.isSubshape ? 40 : 60
        const labelHeight = shape.isSubshape ? 25 : 35

        ctx.fillStyle = "white"
        ctx.fillRect(centerX - labelWidth / 2, centerY - labelHeight / 2, labelWidth, labelHeight)
        ctx.strokeStyle = methodColor + opacity + ")"
        ctx.lineWidth = 1
        ctx.strokeRect(centerX - labelWidth / 2, centerY - labelHeight / 2, labelWidth, labelHeight)

        ctx.fillStyle = methodColor + "1)"
        ctx.font = shape.isSubshape ? "bold 8px sans-serif" : "bold 10px sans-serif"
        ctx.textAlign = "center"
        ctx.fillText(shape.id, centerX, centerY - (shape.isSubshape ? 3 : 5))
        ctx.font = shape.isSubshape ? "6px sans-serif" : "8px sans-serif"
        ctx.fillText(shape.type.toUpperCase(), centerX, centerY + (shape.isSubshape ? 6 : 8))

        ctx.font = "6px sans-serif"
        ctx.fillText(shape.processingMethod.toUpperCase(), centerX, centerY + (shape.isSubshape ? 12 : 16))
      }

      if (showMeasurements) {
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length

        const measurementWidth = 100
        const measurementHeight = 50

        ctx.fillStyle = "rgba(0, 0, 0, 0.8)"
        ctx.fillRect(centerX + 30, centerY - measurementHeight / 2, measurementWidth, measurementHeight)
        ctx.fillStyle = "white"
        ctx.font = "9px sans-serif"
        ctx.textAlign = "left"
        ctx.fillText(`Area: ${shape.area.toFixed(1)}m²`, centerX + 35, centerY - 15)
        ctx.fillText(`Confidence: ${(shape.confidence * 100).toFixed(0)}%`, centerX + 35, centerY - 5)
        ctx.fillText(`Method: ${shape.processingMethod}`, centerX + 35, centerY + 5)
        ctx.fillText(`Formula: ${shape.formula.split(":")[0]}`, centerX + 35, centerY + 15)
      }

      if (showExtractedText && shape.extractedText && shape.extractedText.length > 0) {
        const centerX = shape.coordinates.reduce((sum, coord) => sum + coord[0], 0) / shape.coordinates.length
        const centerY = shape.coordinates.reduce((sum, coord) => sum + coord[1], 0) / shape.coordinates.length

        ctx.fillStyle = "rgba(255, 255, 0, 0.8)"
        ctx.fillRect(centerX - 40, centerY + 40, 80, 20)
        ctx.fillStyle = "black"
        ctx.font = "8px sans-serif"
        ctx.textAlign = "center"
        ctx.fillText(shape.extractedText[0], centerX, centerY + 52)
      }
    })
  }

  const performAIShapeDetection = async () => {
    if (!image) {
      setAnalysisError("No image available for analysis")
      return
    }

    setIsProcessing(true)
    setAnalysisError(null)
    setProcessingStage("Initializing analysis...")

    try {
      console.log(`[v0] Starting ${analysisMethod} shape detection`)
      setProcessingStage(`Running ${analysisMethod} analysis...`)

      const { result, error } = await analyzeShapes(image, analysisMethod)

      if (result) {
        console.log(`[v0] ${analysisMethod} shape analysis successful:`, result)
        setAnalysisResult(result)
        onShapeUpdate?.(result.shapes)
        setProcessingStage("Analysis complete!")
      } else if (error) {
        setAnalysisError(error)
        setProcessingStage("Analysis failed")
      }
    } catch (error) {
      console.error(`[v0] ${analysisMethod} shape detection error:`, error)
      setAnalysisError(error instanceof Error ? error.message : "Unknown error occurred")
      setProcessingStage("Analysis failed")
    } finally {
      setTimeout(() => {
        setIsProcessing(false)
        setProcessingStage("")
      }, 1000)
    }
  }

  const downloadOverlay = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = `shape-overlay-${analysisMethod}.png`
    link.href = canvas.toDataURL()
    link.click()
  }

  const resetDetection = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
    }
    onShapeUpdate?.([])
    setAnalysisResult(null)
    setAnalysisError(null)
    setProcessingStage("")
  }

  const mainShapes = shapes.filter((s) => !s.isSubshape)
  const subshapes = shapes.filter((s) => s.isSubshape)
  const aiDetected = shapes.filter((s) => s.processingMethod === "ai").length
  const cvDetected = shapes.filter((s) => s.processingMethod === "cv").length
  const hybridDetected = shapes.filter((s) => s.processingMethod === "hybrid").length

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Shapes className="w-5 h-5" />
            Enhanced AI Shape Detection & Analysis
          </span>
          <div className="flex items-center gap-2">
            <Badge variant={shapes.length > 0 ? "default" : "secondary"}>
              {mainShapes.length} main + {subshapes.length} sub
            </Badge>
            <Select value={analysisMethod} onValueChange={(value: "hybrid" | "ai" | "cv") => setAnalysisMethod(value)}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hybrid">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Hybrid
                  </div>
                </SelectItem>
                <SelectItem value="ai">
                  <div className="flex items-center gap-2">
                    <Brain className="w-4 h-4" />
                    AI Only
                  </div>
                </SelectItem>
                <SelectItem value="cv">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-4 h-4" />
                    CV Only
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={performAIShapeDetection}
              disabled={isProcessing || !image}
              className="bg-secondary hover:bg-secondary/90"
            >
              {analysisMethod === "hybrid" && <Zap className="w-4 h-4 mr-2" />}
              {analysisMethod === "ai" && <Brain className="w-4 h-4 mr-2" />}
              {analysisMethod === "cv" && <Cpu className="w-4 h-4 mr-2" />}
              {isProcessing ? "Analyzing..." : `${analysisMethod.toUpperCase()} Detect`}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {analysisError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div>{analysisError}</div>
                {analysisError.includes("API key") && (
                  <div className="text-sm">
                    <strong>Suggestion:</strong> Add your GOOGLE_GENERATIVE_AI_API_KEY to the project environment
                    variables.
                  </div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {analysisResult && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div>Enhanced shape analysis completed successfully!</div>
                <div className="text-sm grid grid-cols-2 gap-4">
                  <div>
                    <strong>Results:</strong> {analysisResult.shapes.length} shapes detected
                  </div>
                  <div>
                    <strong>Total Area:</strong> {analysisResult.totalArea.toFixed(1)}m²
                  </div>
                  <div>
                    <strong>Method:</strong> {analysisResult.provider}
                  </div>
                  <div>
                    <strong>Processing Time:</strong> {analysisResult.processingDetails?.processingTime || 0}ms
                  </div>
                </div>
                {analysisResult.processingDetails && (
                  <div className="text-sm text-muted-foreground">
                    <strong>Detection Breakdown:</strong> AI: {analysisResult.processingDetails.aiDetected}, CV:{" "}
                    {analysisResult.processingDetails.cvDetected}, Validated:{" "}
                    {analysisResult.processingDetails.hybridValidated}
                  </div>
                )}
                {analysisResult.validation && analysisResult.validation.errors.length > 0 && (
                  <div className="text-sm text-red-600">
                    <strong>Validation Issues:</strong> {analysisResult.validation.errors.join(", ")}
                  </div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="display" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="display">Display</TabsTrigger>
            <TabsTrigger value="analysis">Analysis</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>

          <TabsContent value="display" className="space-y-4">
            <div className="flex flex-wrap items-center gap-4 p-3 bg-muted rounded-lg">
              <div className="flex items-center space-x-2">
                <Switch id="show-shapes" checked={showShapes} onCheckedChange={setShowShapes} />
                <Label htmlFor="show-shapes" className="flex items-center gap-1">
                  {showShapes ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  Shapes
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-labels" checked={showLabels} onCheckedChange={setShowLabels} />
                <Label htmlFor="show-labels">Labels</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-measurements" checked={showMeasurements} onCheckedChange={setShowMeasurements} />
                <Label htmlFor="show-measurements">Measurements</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-subshapes" checked={showSubshapes} onCheckedChange={setShowSubshapes} />
                <Label htmlFor="show-subshapes">
                  <Layers className="w-4 h-4 inline mr-1" />
                  Subshapes
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-bounding-boxes" checked={showBoundingBoxes} onCheckedChange={setShowBoundingBoxes} />
                <Label htmlFor="show-bounding-boxes">Bounding Boxes</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="show-extracted-text" checked={showExtractedText} onCheckedChange={setShowExtractedText} />
                <Label htmlFor="show-extracted-text">
                  <FileText className="w-4 h-4 inline mr-1" />
                  OCR Text
                </Label>
              </div>

              <div className="flex items-center space-x-2 min-w-32">
                <Label htmlFor="opacity">Opacity</Label>
                <Slider
                  id="opacity"
                  min={10}
                  max={100}
                  step={10}
                  value={shapeOpacity}
                  onValueChange={setShapeOpacity}
                  className="flex-1"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-3 bg-blue-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-600">{aiDetected}</div>
                <div className="text-blue-800 font-medium">AI Detected</div>
              </div>
              <div className="p-3 bg-green-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-600">{cvDetected}</div>
                <div className="text-green-800 font-medium">CV Detected</div>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-purple-600">{hybridDetected}</div>
                <div className="text-purple-800 font-medium">Hybrid Validated</div>
              </div>
              <div className="p-3 bg-orange-50 rounded-lg text-center">
                <div className="text-2xl font-bold text-orange-600">{subshapes.length}</div>
                <div className="text-orange-800 font-medium">Subshapes</div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="export" className="space-y-4">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={downloadOverlay}>
                <Download className="w-4 h-4 mr-1" />
                Export Overlay
              </Button>
              <Button variant="outline" size="sm" onClick={resetDetection}>
                <RotateCcw className="w-4 h-4 mr-1" />
                Reset Detection
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {/* Image with Overlay */}
        <div className="relative border rounded-lg overflow-hidden bg-muted">
          <img
            ref={imageRef}
            src={image || "/placeholder.svg"}
            alt="Land plot with enhanced shape detection"
            className="w-full h-auto"
            onLoad={handleImageLoad}
          />
          <canvas
            ref={canvasRef}
            className="absolute top-0 left-0 w-full h-full pointer-events-none"
            style={{ mixBlendMode: "multiply" }}
          />

          {isProcessing && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <div className="bg-white rounded-lg p-4 flex items-center gap-3">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-secondary"></div>
                <div>
                  <div className="font-medium">Enhanced Shape Analysis</div>
                  <div className="text-sm text-muted-foreground">{processingStage}</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {shapes.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Detected Shapes & Hierarchy
              </h4>
              <div className="text-sm text-muted-foreground">
                {mainShapes.length} main shapes, {subshapes.length} subshapes
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {shapes.map((shape, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg border-l-4 ${shape.isSubshape ? "bg-muted/50 ml-4" : "bg-muted"} ${
                    shape.processingMethod === "ai"
                      ? "border-l-blue-500"
                      : shape.processingMethod === "cv"
                        ? "border-l-green-500"
                        : "border-l-purple-500"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-bold text-secondary text-lg flex items-center gap-2">
                      {shape.isSubshape && <Layers className="w-3 h-3" />}
                      {shape.id}
                    </div>
                    <div className="flex items-center gap-1">
                      <Badge variant="outline">{shape.type}</Badge>
                      <Badge variant="secondary" className="text-xs">
                        {shape.processingMethod}
                      </Badge>
                    </div>
                  </div>
                  <div className="space-y-1 text-sm">
                    <div>
                      <strong>Area:</strong> {shape.area.toFixed(2)}m²
                    </div>
                    <div>
                      <strong>Confidence:</strong> {(shape.confidence * 100).toFixed(0)}%
                    </div>
                    <div>
                      <strong>Formula:</strong> {shape.formula.split(":")[0]}
                    </div>
                    {shape.extractedText && shape.extractedText.length > 0 && (
                      <div>
                        <strong>OCR Text:</strong> {shape.extractedText.join(", ")}
                      </div>
                    )}
                    {Object.entries(shape.measurements)
                      .slice(0, 3)
                      .map(([key, value]) => (
                        <div key={key}>
                          <strong>{key}:</strong> {value.toFixed(2)}m
                        </div>
                      ))}
                    {shape.subshapes && shape.subshapes.length > 0 && (
                      <div className="text-xs text-muted-foreground">Contains {shape.subshapes.length} subshape(s)</div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-primary/10 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="font-semibold text-primary text-xl">
                    {mainShapes.reduce((sum, shape) => sum + shape.area, 0).toFixed(2)}m²
                  </div>
                  <div className="text-sm text-muted-foreground">Main Shapes Total</div>
                </div>
                <div>
                  <div className="font-semibold text-primary text-xl">
                    {shapes.reduce((sum, shape) => sum + shape.area, 0).toFixed(2)}m²
                  </div>
                  <div className="text-sm text-muted-foreground">Combined Total</div>
                </div>
                <div>
                  <div className="font-semibold text-primary text-xl">
                    {(shapes.reduce((sum, shape) => sum + shape.area, 0) / 4047).toFixed(4)}
                  </div>
                  <div className="text-sm text-muted-foreground">Acres</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
