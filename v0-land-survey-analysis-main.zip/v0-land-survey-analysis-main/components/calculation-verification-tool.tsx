"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, XCircle, AlertTriangle, Calculator, Bot, Scale, TrendingUp, Info } from "lucide-react"

interface BoundaryPoint {
  point: string
  coordinates: [number, number]
  length: number
}

interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  triangleValidation?: {
    triangleId: string
    sides: number[]
    area: number
    isValidTriangle: boolean
    triangleType: string
    validationDetails: string[]
  }[]
}

interface AIResult {
  boundaries: BoundaryPoint[]
  totalArea: number
  validation?: ValidationResult
  provider: string
}

interface ManualResult {
  triangles: {
    id: string
    sides: number[]
    area: number
    isValid: boolean
  }[]
  totalArea: number
  unit: string
}

interface VerificationToolProps {
  aiResult?: AIResult
  manualResult?: ManualResult
  onVerificationComplete?: (comparison: ComparisonResult) => void
}

interface ComparisonResult {
  areaDifference: number
  percentageDifference: number
  agreementLevel: "excellent" | "good" | "fair" | "poor"
  recommendations: string[]
  detailedComparison: {
    aiArea: number
    manualArea: number
    triangleComparisons: {
      triangleId: string
      aiTriangle?: { area: number; isValid: boolean }
      manualTriangle?: { area: number; isValid: boolean }
      difference: number
    }[]
  }
}

export function CalculationVerificationTool({ aiResult, manualResult, onVerificationComplete }: VerificationToolProps) {
  const [comparison, setComparison] = useState<ComparisonResult | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  useEffect(() => {
    if (aiResult && manualResult) {
      performVerification()
    }
  }, [aiResult, manualResult])

  const performVerification = () => {
    if (!aiResult || !manualResult) return

    setIsAnalyzing(true)

    // Convert units if necessary (assume AI result is in square meters, manual might be in different units)
    const aiAreaInSqMeters = aiResult.totalArea
    let manualAreaInSqMeters = manualResult.totalArea

    // Convert manual result to square meters if needed
    if (manualResult.unit === "feet") {
      manualAreaInSqMeters = manualResult.totalArea * 0.092903 // sq ft to sq m
    } else if (manualResult.unit === "yards") {
      manualAreaInSqMeters = manualResult.totalArea * 0.836127 // sq yd to sq m
    }

    const areaDifference = Math.abs(aiAreaInSqMeters - manualAreaInSqMeters)
    const percentageDifference = (areaDifference / Math.max(aiAreaInSqMeters, manualAreaInSqMeters)) * 100

    // Determine agreement level
    let agreementLevel: ComparisonResult["agreementLevel"]
    if (percentageDifference <= 5) {
      agreementLevel = "excellent"
    } else if (percentageDifference <= 15) {
      agreementLevel = "good"
    } else if (percentageDifference <= 30) {
      agreementLevel = "fair"
    } else {
      agreementLevel = "poor"
    }

    // Generate recommendations
    const recommendations: string[] = []

    if (agreementLevel === "excellent") {
      recommendations.push("Results show excellent agreement. Both methods are consistent.")
    } else if (agreementLevel === "good") {
      recommendations.push("Results show good agreement with minor differences.")
      recommendations.push("Consider checking scale calibration for improved accuracy.")
    } else if (agreementLevel === "fair") {
      recommendations.push("Moderate differences detected. Review the following:")
      recommendations.push("• Verify scale reference in AI analysis")
      recommendations.push("• Double-check manual triangle measurements")
      recommendations.push("• Ensure consistent measurement units")
    } else {
      recommendations.push("Significant differences detected. Investigation required:")
      recommendations.push("• Re-examine AI boundary detection accuracy")
      recommendations.push("• Verify all manual triangle measurements")
      recommendations.push("• Check for measurement or scale errors")
      recommendations.push("• Consider using coordinate-based validation")
    }

    // Triangle-level comparison
    const triangleComparisons: ComparisonResult["detailedComparison"]["triangleComparisons"] = []

    // Compare AI validation triangles with manual triangles
    const aiTriangles = aiResult.validation?.triangleValidation || []
    const manualTriangles = manualResult.triangles

    const maxTriangles = Math.max(aiTriangles.length, manualTriangles.length)

    for (let i = 0; i < maxTriangles; i++) {
      const aiTriangle = aiTriangles[i]
      const manualTriangle = manualTriangles[i]

      const triangleId = aiTriangle?.triangleId || manualTriangle?.id || `T${i + 1}`

      let difference = 0
      if (aiTriangle && manualTriangle) {
        difference = Math.abs(aiTriangle.area - manualTriangle.area)
      }

      triangleComparisons.push({
        triangleId,
        aiTriangle: aiTriangle ? { area: aiTriangle.area, isValid: aiTriangle.isValidTriangle } : undefined,
        manualTriangle: manualTriangle ? { area: manualTriangle.area, isValid: manualTriangle.isValid } : undefined,
        difference,
      })
    }

    const comparisonResult: ComparisonResult = {
      areaDifference,
      percentageDifference,
      agreementLevel,
      recommendations,
      detailedComparison: {
        aiArea: aiAreaInSqMeters,
        manualArea: manualAreaInSqMeters,
        triangleComparisons,
      },
    }

    setComparison(comparisonResult)
    setIsAnalyzing(false)
    onVerificationComplete?.(comparisonResult)
  }

  const getAgreementColor = (level: ComparisonResult["agreementLevel"]) => {
    switch (level) {
      case "excellent":
        return "text-green-700 bg-green-50 border-green-200"
      case "good":
        return "text-blue-700 bg-blue-50 border-blue-200"
      case "fair":
        return "text-yellow-700 bg-yellow-50 border-yellow-200"
      case "poor":
        return "text-red-700 bg-red-50 border-red-200"
    }
  }

  const getAgreementIcon = (level: ComparisonResult["agreementLevel"]) => {
    switch (level) {
      case "excellent":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "good":
        return <CheckCircle className="h-5 w-5 text-blue-600" />
      case "fair":
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />
      case "poor":
        return <XCircle className="h-5 w-5 text-red-600" />
    }
  }

  if (!aiResult && !manualResult) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Scale className="h-5 w-5" />
            Calculation Verification Tool
          </CardTitle>
          <CardDescription>Compare AI boundary detection results with manual triangle calculations</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Perform both AI analysis and manual calculations to enable verification comparison.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Scale className="h-5 w-5" />
          Calculation Verification Tool
        </CardTitle>
        <CardDescription>Compare AI boundary detection results with manual triangle calculations</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="detailed">Detailed Comparison</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {/* Results Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* AI Results */}
              <Card className="border-blue-200 bg-blue-50">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-blue-800">
                    <Bot className="h-4 w-4" />
                    AI Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {aiResult ? (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Total Area:</span>
                        <span className="font-medium">{aiResult.totalArea.toFixed(2)} m²</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Boundaries:</span>
                        <span className="font-medium">{aiResult.boundaries.length} points</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Provider:</span>
                        <Badge variant="secondary">{aiResult.provider}</Badge>
                      </div>
                      {aiResult.validation && (
                        <div className="flex justify-between">
                          <span>Validation:</span>
                          <Badge variant={aiResult.validation.isValid ? "default" : "destructive"}>
                            {aiResult.validation.isValid ? "Valid" : "Issues Found"}
                          </Badge>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No AI analysis available</p>
                  )}
                </CardContent>
              </Card>

              {/* Manual Results */}
              <Card className="border-green-200 bg-green-50">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-green-800">
                    <Calculator className="h-4 w-4" />
                    Manual Calculation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {manualResult ? (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Total Area:</span>
                        <span className="font-medium">
                          {manualResult.totalArea.toFixed(2)} {manualResult.unit}²
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Triangles:</span>
                        <span className="font-medium">{manualResult.triangles.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Valid Triangles:</span>
                        <span className="font-medium">
                          {manualResult.triangles.filter((t) => t.isValid).length} / {manualResult.triangles.length}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Unit:</span>
                        <Badge variant="secondary">{manualResult.unit}</Badge>
                      </div>
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No manual calculation available</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Comparison Results */}
            {comparison && (
              <Card className={`border-2 ${getAgreementColor(comparison.agreementLevel)}`}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getAgreementIcon(comparison.agreementLevel)}
                    Verification Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{comparison.percentageDifference.toFixed(1)}%</div>
                      <div className="text-sm text-muted-foreground">Difference</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold capitalize">{comparison.agreementLevel}</div>
                      <div className="text-sm text-muted-foreground">Agreement</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">{comparison.areaDifference.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">Area Diff (m²)</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="detailed" className="space-y-4">
            {comparison && (
              <div className="space-y-4">
                {/* Area Comparison */}
                <Card>
                  <CardHeader>
                    <CardTitle>Area Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span>AI Analysis:</span>
                        <span className="font-medium">{comparison.detailedComparison.aiArea.toFixed(2)} m²</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Manual Calculation:</span>
                        <span className="font-medium">{comparison.detailedComparison.manualArea.toFixed(2)} m²</span>
                      </div>
                      <div className="border-t pt-2 flex justify-between items-center font-semibold">
                        <span>Absolute Difference:</span>
                        <span>{comparison.areaDifference.toFixed(2)} m²</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Triangle-by-Triangle Comparison */}
                <Card>
                  <CardHeader>
                    <CardTitle>Triangle Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {comparison.detailedComparison.triangleComparisons.map((triangle, index) => (
                        <div key={index} className="border rounded-lg p-3">
                          <div className="font-medium mb-2">{triangle.triangleId}</div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">AI: </span>
                              {triangle.aiTriangle ? (
                                <span className={triangle.aiTriangle.isValid ? "text-green-600" : "text-red-600"}>
                                  {triangle.aiTriangle.area.toFixed(2)} m²
                                  {!triangle.aiTriangle.isValid && " (Invalid)"}
                                </span>
                              ) : (
                                <span className="text-muted-foreground">N/A</span>
                              )}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Manual: </span>
                              {triangle.manualTriangle ? (
                                <span className={triangle.manualTriangle.isValid ? "text-green-600" : "text-red-600"}>
                                  {triangle.manualTriangle.area.toFixed(2)} m²
                                  {!triangle.manualTriangle.isValid && " (Invalid)"}
                                </span>
                              ) : (
                                <span className="text-muted-foreground">N/A</span>
                              )}
                            </div>
                          </div>
                          {triangle.aiTriangle && triangle.manualTriangle && (
                            <div className="mt-2 text-sm">
                              <span className="text-muted-foreground">Difference: </span>
                              <span className="font-medium">{triangle.difference.toFixed(2)} m²</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            {comparison && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {comparison.recommendations.map((recommendation, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <p className="text-sm">{recommendation}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        {aiResult && manualResult && !comparison && (
          <Button onClick={performVerification} disabled={isAnalyzing} className="w-full">
            {isAnalyzing ? "Analyzing..." : "Perform Verification"}
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
