"use client"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Calculator, CheckCircle, AlertTriangle, Info } from "lucide-react"
import {
  heronsFormula,
  baseHeightFormula,
  sasFormula,
  equilateralFormula,
  rightTriangleFormula,
  shoelaceFormula,
  autoSelectFormula,
  type Point,
  type CalculationResult,
} from "@/lib/survey-calculations"

interface CalculationEngineProps {
  boundaries?: Array<{ point: string; coordinates: [number, number]; length: number }>
  onCalculationComplete?: (result: any) => void
}

export function CalculationEngine({ boundaries, onCalculationComplete }: CalculationEngineProps) {
  const [selectedFormula, setSelectedFormula] = useState("auto")
  const [inputs, setInputs] = useState<Record<string, string>>({})
  const [result, setResult] = useState<CalculationResult | null>(null)
  const [isCalculating, setIsCalculating] = useState(false)

  const formulas = [
    { value: "auto", label: "Auto-Select Best Formula" },
    { value: "herons", label: "Heron's Formula (3 sides)" },
    { value: "baseHeight", label: "Base × Height" },
    { value: "sas", label: "SAS (two sides + included angle)" },
    { value: "asa", label: "ASA/AAS (via Law of Sines)" },
    { value: "equilateral", label: "Equilateral Triangle" },
    { value: "rightTriangle", label: "Right Triangle" },
    { value: "shoelace", label: "Shoelace Formula (coordinates)" },
    { value: "vectorCross", label: "Vector Cross Product" },
    { value: "circumradius", label: "Circumradius Formula" },
    { value: "inradius", label: "Inradius Formula" },
    { value: "determinant", label: "Determinant Formula" },
    { value: "surveying", label: "Surveying/Polygon Extension" },
  ]

  const handleInputChange = (key: string, value: string) => {
    setInputs((prev) => ({ ...prev, [key]: value }))
  }

  const calculateArea = async () => {
    setIsCalculating(true)

    // Simulate calculation time
    await new Promise((resolve) => setTimeout(resolve, 500))

    let calculationResult: CalculationResult

    try {
      switch (selectedFormula) {
        case "auto":
          if (boundaries && boundaries.length > 0) {
            const points: Point[] = boundaries.map((b) => ({ x: b.coordinates[0], y: b.coordinates[1] }))
            calculationResult = autoSelectFormula({ points })
          } else {
            calculationResult = {
              area: 0,
              formula: "Auto-Select",
              details: "No boundary data available",
              isValid: false,
              error: "No data",
            }
          }
          break

        case "herons":
          const a = Number.parseFloat(inputs.sideA || "0")
          const b = Number.parseFloat(inputs.sideB || "0")
          const c = Number.parseFloat(inputs.sideC || "0")
          calculationResult = heronsFormula(a, b, c)
          break

        case "baseHeight":
          const base = Number.parseFloat(inputs.base || "0")
          const height = Number.parseFloat(inputs.height || "0")
          calculationResult = baseHeightFormula(base, height)
          break

        case "sas":
          const sideA = Number.parseFloat(inputs.sideA || "0")
          const sideB = Number.parseFloat(inputs.sideB || "0")
          const angle = Number.parseFloat(inputs.angle || "0")
          calculationResult = sasFormula(sideA, sideB, angle)
          break

        case "equilateral":
          const side = Number.parseFloat(inputs.side || "0")
          calculationResult = equilateralFormula(side)
          break

        case "rightTriangle":
          const legA = Number.parseFloat(inputs.legA || "0")
          const legB = Number.parseFloat(inputs.legB || "0")
          calculationResult = rightTriangleFormula(legA, legB)
          break

        case "shoelace":
          if (boundaries && boundaries.length > 0) {
            const points: Point[] = boundaries.map((b) => ({ x: b.coordinates[0], y: b.coordinates[1] }))
            calculationResult = shoelaceFormula(points)
          } else {
            calculationResult = {
              area: 0,
              formula: "Shoelace Formula",
              details: "No coordinate data available",
              isValid: false,
              error: "No coordinates",
            }
          }
          break

        default:
          calculationResult = {
            area: 0,
            formula: "Unknown",
            details: "Formula not implemented",
            isValid: false,
            error: "Not implemented",
          }
      }

      setResult(calculationResult)

      if (calculationResult.isValid && onCalculationComplete) {
        onCalculationComplete({
          area: calculationResult.area,
          formula: calculationResult.formula,
          details: calculationResult.details,
        })
      }
    } catch (error) {
      setResult({
        area: 0,
        formula: selectedFormula,
        details: "Calculation error occurred",
        isValid: false,
        error: error instanceof Error ? error.message : "Unknown error",
      })
    }

    setIsCalculating(false)
  }

  const renderInputFields = () => {
    switch (selectedFormula) {
      case "herons":
        return (
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="sideA">Side A</Label>
              <Input
                id="sideA"
                type="number"
                placeholder="Length"
                value={inputs.sideA || ""}
                onChange={(e) => handleInputChange("sideA", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="sideB">Side B</Label>
              <Input
                id="sideB"
                type="number"
                placeholder="Length"
                value={inputs.sideB || ""}
                onChange={(e) => handleInputChange("sideB", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="sideC">Side C</Label>
              <Input
                id="sideC"
                type="number"
                placeholder="Length"
                value={inputs.sideC || ""}
                onChange={(e) => handleInputChange("sideC", e.target.value)}
              />
            </div>
          </div>
        )

      case "baseHeight":
        return (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="base">Base</Label>
              <Input
                id="base"
                type="number"
                placeholder="Base length"
                value={inputs.base || ""}
                onChange={(e) => handleInputChange("base", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="height">Height</Label>
              <Input
                id="height"
                type="number"
                placeholder="Height"
                value={inputs.height || ""}
                onChange={(e) => handleInputChange("height", e.target.value)}
              />
            </div>
          </div>
        )

      case "sas":
        return (
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="sideA">Side A</Label>
              <Input
                id="sideA"
                type="number"
                placeholder="Length"
                value={inputs.sideA || ""}
                onChange={(e) => handleInputChange("sideA", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="sideB">Side B</Label>
              <Input
                id="sideB"
                type="number"
                placeholder="Length"
                value={inputs.sideB || ""}
                onChange={(e) => handleInputChange("sideB", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="angle">Included Angle (°)</Label>
              <Input
                id="angle"
                type="number"
                placeholder="Degrees"
                value={inputs.angle || ""}
                onChange={(e) => handleInputChange("angle", e.target.value)}
              />
            </div>
          </div>
        )

      case "equilateral":
        return (
          <div>
            <Label htmlFor="side">Side Length</Label>
            <Input
              id="side"
              type="number"
              placeholder="Side length"
              value={inputs.side || ""}
              onChange={(e) => handleInputChange("side", e.target.value)}
            />
          </div>
        )

      case "rightTriangle":
        return (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="legA">Leg A</Label>
              <Input
                id="legA"
                type="number"
                placeholder="Length"
                value={inputs.legA || ""}
                onChange={(e) => handleInputChange("legA", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="legB">Leg B</Label>
              <Input
                id="legB"
                type="number"
                placeholder="Length"
                value={inputs.legB || ""}
                onChange={(e) => handleInputChange("legB", e.target.value)}
              />
            </div>
          </div>
        )

      case "auto":
      case "shoelace":
        return (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              This formula uses coordinate data from detected boundaries. No manual input required.
            </AlertDescription>
          </Alert>
        )

      default:
        return (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>Input fields for this formula will be available in the next update.</AlertDescription>
          </Alert>
        )
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Mathematical Calculations Engine
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <Label htmlFor="formula-select">Select Calculation Formula</Label>
          <Select value={selectedFormula} onValueChange={setSelectedFormula}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a formula" />
            </SelectTrigger>
            <SelectContent>
              {formulas.map((formula) => (
                <SelectItem key={formula.value} value={formula.value}>
                  {formula.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">{renderInputFields()}</div>

        <Button onClick={calculateArea} disabled={isCalculating} className="w-full bg-secondary hover:bg-secondary/90">
          {isCalculating ? "Calculating..." : "Calculate Area"}
        </Button>

        {result && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              {result.isValid ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-red-500" />
              )}
              <Badge variant={result.isValid ? "default" : "destructive"}>{result.formula}</Badge>
            </div>

            {result.isValid ? (
              <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                <div className="text-2xl font-bold text-green-700 dark:text-green-300">
                  {result.area.toLocaleString()} sq units
                </div>
                <div className="text-sm text-green-600 dark:text-green-400 mt-1">{result.details}</div>
              </div>
            ) : (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  {result.error}: {result.details}
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}

        {boundaries && boundaries.length > 0 && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <div className="text-sm font-medium mb-2">Available Boundary Data:</div>
            <div className="text-xs text-muted-foreground">
              {boundaries.length} boundary points detected with coordinates
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
