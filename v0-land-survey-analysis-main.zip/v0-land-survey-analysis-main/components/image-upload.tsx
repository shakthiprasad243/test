"use client"

import type React from "react"
import { useState, useCallback } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileImage, X, CheckCircle, AlertCircle } from "lucide-react"

interface ImageUploadProps {
  onImageUpload: (imageData: string, file: File) => void
  uploadedImage: string | null
  onRemoveImage: () => void
}

export function ImageUpload({ onImageUpload, uploadedImage, onRemoveImage }: ImageUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fileInfo, setFileInfo] = useState<{ name: string; size: string } | null>(null)

  const validateFile = (file: File): string | null => {
    const maxSize = 10 * 1024 * 1024 // 10MB
    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/gif"]

    if (!allowedTypes.includes(file.type)) {
      return "Please upload a valid image file (JPG, PNG, GIF)"
    }

    if (file.size > maxSize) {
      return "File size must be less than 10MB"
    }

    return null
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const processFile = useCallback(
    (file: File) => {
      const validationError = validateFile(file)
      if (validationError) {
        setError(validationError)
        return
      }

      setError(null)
      setIsUploading(true)
      setUploadProgress(0)

      const reader = new FileReader()

      reader.onprogress = (e) => {
        if (e.lengthComputable) {
          const progress = (e.loaded / e.total) * 100
          setUploadProgress(progress)
        }
      }

      reader.onload = (e) => {
        const result = e.target?.result as string
        setFileInfo({
          name: file.name,
          size: formatFileSize(file.size),
        })
        onImageUpload(result, file)
        setIsUploading(false)
        setUploadProgress(100)
      }

      reader.onerror = () => {
        setError("Failed to read the file")
        setIsUploading(false)
        setUploadProgress(0)
      }

      reader.readAsDataURL(file)
    },
    [onImageUpload],
  )

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      processFile(file)
    }
  }

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragOver(false)

      const files = Array.from(e.dataTransfer.files)
      const imageFile = files.find((file) => file.type.startsWith("image/"))

      if (imageFile) {
        processFile(imageFile)
      } else {
        setError("Please drop an image file")
      }
    },
    [processFile],
  )

  const handleRemove = () => {
    onRemoveImage()
    setFileInfo(null)
    setUploadProgress(0)
    setError(null)
  }

  return (
    <Card>
      <CardContent className="p-6">
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragOver
              ? "border-secondary bg-secondary/10"
              : uploadedImage
                ? "border-green-500 bg-green-50 dark:bg-green-950/20"
                : "border-border hover:border-secondary/50"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {uploadedImage ? (
            <div className="space-y-4">
              <div className="relative inline-block">
                <img
                  src={uploadedImage || "/placeholder.svg"}
                  alt="Uploaded land plot"
                  className="max-w-full h-64 object-contain mx-auto rounded-lg shadow-md"
                />
                <Button
                  variant="destructive"
                  size="sm"
                  className="absolute -top-2 -right-2 rounded-full w-8 h-8 p-0"
                  onClick={handleRemove}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {fileInfo && (
                <div className="flex items-center justify-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <Badge
                    variant="secondary"
                    className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                  >
                    {fileInfo.name} ({fileInfo.size})
                  </Badge>
                </div>
              )}

              <p className="text-sm text-muted-foreground">
                Image uploaded successfully. Ready for boundary detection.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {isUploading ? (
                <div className="space-y-3">
                  <Upload className="w-12 h-12 text-secondary mx-auto animate-pulse" />
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Uploading image...</p>
                    <Progress value={uploadProgress} className="w-full max-w-xs mx-auto" />
                    <p className="text-xs text-muted-foreground">{Math.round(uploadProgress)}% complete</p>
                  </div>
                </div>
              ) : (
                <>
                  <FileImage className="w-12 h-12 text-muted-foreground mx-auto" />
                  <div className="space-y-2">
                    <Label htmlFor="image-upload" className="cursor-pointer">
                      <Button asChild className="bg-secondary hover:bg-secondary/90">
                        <span>
                          <Upload className="w-4 h-4 mr-2" />
                          Choose Image File
                        </span>
                      </Button>
                    </Label>
                    <Input
                      id="image-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">
                      Drag and drop your land plot image here, or click to browse
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Supports JPG, PNG, GIF formats. Maximum file size: 10MB
                    </p>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
