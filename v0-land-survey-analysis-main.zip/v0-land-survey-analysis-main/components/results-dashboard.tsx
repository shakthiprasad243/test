"use client"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { Download, FileText, Share2, CheckCircle, MapPin, Calculator, TrendingUp, Info } from "lucide-react"

interface Triangle {
  id: number
  vertices: string[]
  area: number
  formula: string
  coordinates?: Array<[number, number]>
}

interface BoundaryPoint {
  point: string
  coordinates: [number, number]
  length: number
}

interface ResultsDashboardProps {
  boundaries: BoundaryPoint[]
  triangles: Triangle[]
  totalArea: number
  totalAcres: number
  calculationMethod: string
  scaleReference?: string
}

export function ResultsDashboard({
  boundaries,
  triangles,
  totalArea,
  totalAcres,
  calculationMethod,
  scaleReference,
}: ResultsDashboardProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const [isExporting, setIsExporting] = useState(false)

  // Prepare chart data
  const triangleChartData = triangles.map((triangle, index) => ({
    name: `Triangle ${triangle.id}`,
    area: triangle.area,
    percentage: ((triangle.area / totalArea) * 100).toFixed(1),
  }))

  const boundaryChartData = boundaries.map((boundary, index) => ({
    name: `Side ${boundary.point}`,
    length: boundary.length,
  }))

  const pieColors = ["#6366f1", "#3b82f6", "#10b981", "#f59e0b", "#ef4444"]

  const exportResults = async (format: "pdf" | "csv" | "json") => {
    setIsExporting(true)

    // Simulate export process
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const data = {
      timestamp: new Date().toISOString(),
      boundaries,
      triangles,
      totalArea,
      totalAcres,
      calculationMethod,
      scaleReference,
    }

    switch (format) {
      case "json":
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `survey-results-${Date.now()}.json`
        a.click()
        URL.revokeObjectURL(url)
        break

      case "csv":
        const csvContent = [
          "Boundary,X,Y,Length",
          ...boundaries.map((b) => `${b.point},${b.coordinates[0]},${b.coordinates[1]},${b.length}`),
          "",
          "Triangle,Vertices,Area,Formula",
          ...triangles.map((t) => `${t.id},"${t.vertices.join(", ")}",${t.area},${t.formula}`),
          "",
          `Total Area,${totalArea}`,
          `Total Acres,${totalAcres}`,
          `Method,${calculationMethod}`,
        ].join("\n")

        const csvBlob = new Blob([csvContent], { type: "text/csv" })
        const csvUrl = URL.createObjectURL(csvBlob)
        const csvLink = document.createElement("a")
        csvLink.href = csvUrl
        csvLink.download = `survey-results-${Date.now()}.csv`
        csvLink.click()
        URL.revokeObjectURL(csvUrl)
        break

      case "pdf":
        // In a real implementation, you would use a PDF library like jsPDF
        alert("PDF export would be implemented with a PDF library in production")
        break
    }

    setIsExporting(false)
  }

  const shareResults = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Land Survey Results",
          text: `Survey completed: ${totalArea.toLocaleString()} sq units (${totalAcres} acres)`,
          url: window.location.href,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    } else {
      // Fallback: copy to clipboard
      const shareText = `Land Survey Results:\nTotal Area: ${totalArea.toLocaleString()} sq units\nTotal Acres: ${totalAcres}\nMethod: ${calculationMethod}`
      navigator.clipboard.writeText(shareText)
      alert("Results copied to clipboard!")
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Survey Analysis Results
          </span>
          <div className="flex items-center gap-2">
            <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
              <CheckCircle className="w-3 h-3 mr-1" />
              Complete
            </Badge>
            <Button variant="outline" size="sm" onClick={shareResults}>
              <Share2 className="w-4 h-4 mr-1" />
              Share
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="boundaries">Boundaries</TabsTrigger>
            <TabsTrigger value="triangulation">Triangulation</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-secondary">{totalArea.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Square Units</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-secondary">{totalAcres}</div>
                  <div className="text-sm text-muted-foreground">Acres</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-secondary">{boundaries.length}</div>
                  <div className="text-sm text-muted-foreground">Boundary Points</div>
                </CardContent>
              </Card>
            </div>

            {/* Area Distribution Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Area Distribution by Triangle</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={triangleChartData}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="area"
                          label={({ name, percentage }) => `${name}: ${percentage}%`}
                        >
                          {triangleChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: any) => [`${value.toLocaleString()} sq units`, "Area"]} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-3">
                    {triangleChartData.map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: pieColors[index % pieColors.length] }}
                          />
                          <span className="text-sm font-medium">{item.name}</span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {item.area.toLocaleString()} sq units ({item.percentage}%)
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Calculation Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Calculation Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Method Used:</span>
                  <Badge variant="outline">{calculationMethod}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Triangles Generated:</span>
                  <span className="font-medium">{triangles.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Boundary Points:</span>
                  <span className="font-medium">{boundaries.length}</span>
                </div>
                {scaleReference && (
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Scale Reference:</span>
                    <span className="font-medium text-sm">{scaleReference}</span>
                  </div>
                )}
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Accuracy:</span>
                  <Badge
                    variant="default"
                    className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                  >
                    High Precision
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="boundaries" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Boundary Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Boundary Lengths Chart */}
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={boundaryChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value: any) => [`${value} units`, "Length"]} />
                        <Bar dataKey="length" fill="#6366f1" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Boundary Details Table */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {boundaries.map((boundary, index) => (
                      <div key={index} className="p-4 bg-muted rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div className="font-bold text-lg">Point {boundary.point}</div>
                          <Badge variant="secondary">{boundary.length} units</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Coordinates: ({boundary.coordinates[0]}, {boundary.coordinates[1]})
                        </div>
                        <div className="mt-2">
                          <Progress
                            value={(boundary.length / Math.max(...boundaries.map((b) => b.length))) * 100}
                            className="h-2"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="triangulation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Triangulation Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {triangles.map((triangle, index) => (
                  <div key={triangle.id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="font-bold text-lg">Triangle {triangle.id}</div>
                        <div className="text-sm text-muted-foreground">Vertices: {triangle.vertices.join(" → ")}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-secondary">{triangle.area.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">sq units</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{triangle.formula}</Badge>
                      <div className="text-sm text-muted-foreground">
                        {((triangle.area / totalArea) * 100).toFixed(1)}% of total area
                      </div>
                    </div>

                    <div className="mt-2">
                      <Progress value={(triangle.area / totalArea) * 100} className="h-2" />
                    </div>
                  </div>
                ))}

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Triangulation uses the Delaunay method for optimal triangle distribution and accuracy. Each triangle
                    is calculated independently and validated for geometric consistency.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="export" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Download className="w-5 h-5" />
                  Export Results
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    variant="outline"
                    onClick={() => exportResults("json")}
                    disabled={isExporting}
                    className="h-20 flex-col"
                  >
                    <FileText className="w-6 h-6 mb-2" />
                    <span>JSON Data</span>
                    <span className="text-xs text-muted-foreground">Complete dataset</span>
                  </Button>

                  <Button
                    variant="outline"
                    onClick={() => exportResults("csv")}
                    disabled={isExporting}
                    className="h-20 flex-col"
                  >
                    <FileText className="w-6 h-6 mb-2" />
                    <span>CSV Report</span>
                    <span className="text-xs text-muted-foreground">Spreadsheet format</span>
                  </Button>

                  <Button
                    variant="outline"
                    onClick={() => exportResults("pdf")}
                    disabled={isExporting}
                    className="h-20 flex-col"
                  >
                    <FileText className="w-6 h-6 mb-2" />
                    <span>PDF Report</span>
                    <span className="text-xs text-muted-foreground">Professional format</span>
                  </Button>
                </div>

                {isExporting && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-secondary"></div>
                      <span className="text-sm">Preparing export...</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                )}

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Exported files include all boundary coordinates, triangulation data, area calculations, and metadata
                    for professional survey documentation.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
