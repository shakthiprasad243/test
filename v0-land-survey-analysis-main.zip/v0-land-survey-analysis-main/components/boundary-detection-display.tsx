"use client"
import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, EyeOff, Download, RotateCcw, Brain, AlertCircle, CheckCircle } from "lucide-react"
import { analyzeBoundaries } from "@/lib/ai-boundary-detection"

interface BoundaryPoint {
  point: string
  coordinates: [number, number]
  length: number
}

interface BoundaryDetectionDisplayProps {
  image: string
  boundaries: BoundaryPoint[]
  onBoundaryUpdate?: (boundaries: BoundaryPoint[]) => void
}

export function BoundaryDetectionDisplay({ image, boundaries, onBoundaryUpdate }: BoundaryDetectionDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imageRef = useRef<HTMLImageElement>(null)
  const [showBoundaries, setShowBoundaries] = useState(true)
  const [showLabels, setShowLabels] = useState(true)
  const [showTriangulation, setShowTriangulation] = useState(false)
  const [boundaryOpacity, setBoundaryOpacity] = useState([80])
  const [isProcessing, setIsProcessing] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<any>(null)
  const [analysisError, setAnalysisError] = useState<string | null>(null)

  // Mock triangulation data
  const triangles = [
    {
      vertices: [
        [0, 0],
        [150, 0],
        [150, 200],
      ],
    },
    {
      vertices: [
        [0, 0],
        [150, 200],
        [0, 200],
      ],
    },
  ]

  useEffect(() => {
    if (imageLoaded && canvasRef.current) {
      drawBoundaries()
    }
  }, [imageLoaded, showBoundaries, showLabels, showTriangulation, boundaryOpacity])

  const handleImageLoad = () => {
    setImageLoaded(true)
  }

  const drawBoundaries = () => {
    const canvas = canvasRef.current
    const img = imageRef.current
    if (!canvas || !img) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size to match image
    canvas.width = img.naturalWidth
    canvas.height = img.naturalHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (!showBoundaries) return

    // Set drawing styles
    ctx.strokeStyle = `rgba(99, 102, 241, ${boundaryOpacity[0] / 100})`
    ctx.fillStyle = `rgba(99, 102, 241, ${boundaryOpacity[0] / 100})`
    ctx.lineWidth = 3
    ctx.font = "14px sans-serif"

    // Draw triangulation if enabled
    if (showTriangulation) {
      ctx.strokeStyle = `rgba(34, 197, 94, ${boundaryOpacity[0] / 200})`
      ctx.lineWidth = 1
      ctx.setLineDash([5, 5])

      triangles.forEach((triangle) => {
        ctx.beginPath()
        triangle.vertices.forEach((vertex, index) => {
          const [x, y] = vertex
          if (index === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        })
        ctx.closePath()
        ctx.stroke()
      })

      ctx.setLineDash([])
    }

    // Draw boundary lines
    ctx.strokeStyle = `rgba(99, 102, 241, ${boundaryOpacity[0] / 100})`
    ctx.lineWidth = 3

    if (boundaries.length > 0) {
      ctx.beginPath()
      boundaries.forEach((boundary, index) => {
        const [x, y] = boundary.coordinates
        if (index === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      })
      ctx.closePath()
      ctx.stroke()

      // Draw boundary points and labels
      boundaries.forEach((boundary) => {
        const [x, y] = boundary.coordinates

        // Draw point
        ctx.beginPath()
        ctx.arc(x, y, 6, 0, 2 * Math.PI)
        ctx.fillStyle = `rgba(99, 102, 241, ${boundaryOpacity[0] / 100})`
        ctx.fill()
        ctx.strokeStyle = "white"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw label if enabled
        if (showLabels) {
          ctx.fillStyle = "white"
          ctx.fillRect(x + 10, y - 20, 30, 20)
          ctx.strokeStyle = `rgba(99, 102, 241, ${boundaryOpacity[0] / 100})`
          ctx.lineWidth = 1
          ctx.strokeRect(x + 10, y - 20, 30, 20)

          ctx.fillStyle = `rgba(99, 102, 241, ${boundaryOpacity[0] / 100})`
          ctx.font = "bold 12px sans-serif"
          ctx.fillText(boundary.point, x + 15, y - 8)
        }
      })
    }
  }

  const performAIBoundaryDetection = async () => {
    if (!image) {
      setAnalysisError("No image available for analysis")
      return
    }

    setIsProcessing(true)
    setAnalysisError(null)

    try {
      console.log("[v0] Starting AI boundary detection with Gemini")

      const { result, error } = await analyzeBoundaries(image)

      if (result) {
        console.log("[v0] AI analysis successful:", result)
        setAnalysisResult(result)
        onBoundaryUpdate?.(result.boundaries)
      } else if (error) {
        setAnalysisError(error)
      }
    } catch (error) {
      console.error("[v0] AI boundary detection error:", error)
      setAnalysisError(error instanceof Error ? error.message : "Unknown error occurred")
    } finally {
      setIsProcessing(false)
    }
  }

  const downloadOverlay = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = "boundary-overlay.png"
    link.href = canvas.toDataURL()
    link.click()
  }

  const resetDetection = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
    }
    onBoundaryUpdate?.([])
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>AI Boundary Detection & Visualization</span>
          <div className="flex items-center gap-2">
            <Badge variant={boundaries.length > 0 ? "default" : "secondary"}>
              {boundaries.length} boundaries detected
            </Badge>
            <Button
              onClick={performAIBoundaryDetection}
              disabled={isProcessing || !image}
              className="bg-secondary hover:bg-secondary/90"
            >
              <Brain className="w-4 h-4 mr-2" />
              {isProcessing ? "Analyzing..." : "AI Detect (Gemini)"}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {analysisError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div>{analysisError}</div>
                {analysisError.includes("API key") && (
                  <div className="text-sm">
                    <strong>Suggestion:</strong> Add your GOOGLE_GENERATIVE_AI_API_KEY to the project environment
                    variables.
                  </div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {analysisResult && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              <div className="space-y-2">
                <div>Analysis completed successfully with Gemini!</div>
                <div className="text-sm">
                  <strong>Results:</strong> {analysisResult.boundaries.length} boundaries detected,
                  {analysisResult.totalArea.toFixed(1)}m² total area (confidence:{" "}
                  {(analysisResult.scale.confidence * 100).toFixed(0)}%)
                </div>
                {analysisResult.notes && (
                  <div className="text-sm text-muted-foreground">
                    <strong>Notes:</strong> {analysisResult.notes}
                  </div>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-4 p-3 bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <Switch id="show-boundaries" checked={showBoundaries} onCheckedChange={setShowBoundaries} />
            <Label htmlFor="show-boundaries" className="flex items-center gap-1">
              {showBoundaries ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              Boundaries
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="show-labels" checked={showLabels} onCheckedChange={setShowLabels} />
            <Label htmlFor="show-labels">Labels</Label>
          </div>

          <div className="flex items-center space-x-2">
            <Switch id="show-triangulation" checked={showTriangulation} onCheckedChange={setShowTriangulation} />
            <Label htmlFor="show-triangulation">Triangulation</Label>
          </div>

          <div className="flex items-center space-x-2 min-w-32">
            <Label htmlFor="opacity">Opacity</Label>
            <Slider
              id="opacity"
              min={10}
              max={100}
              step={10}
              value={boundaryOpacity}
              onValueChange={setBoundaryOpacity}
              className="flex-1"
            />
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <Button variant="outline" size="sm" onClick={downloadOverlay}>
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
            <Button variant="outline" size="sm" onClick={resetDetection}>
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset
            </Button>
          </div>
        </div>

        {/* Image with Overlay */}
        <div className="relative border rounded-lg overflow-hidden bg-muted">
          <img
            ref={imageRef}
            src={image || "/placeholder.svg"}
            alt="Land plot with boundary detection"
            className="w-full h-auto"
            onLoad={handleImageLoad}
          />
          <canvas
            ref={canvasRef}
            className="absolute top-0 left-0 w-full h-full pointer-events-none"
            style={{ mixBlendMode: "multiply" }}
          />

          {isProcessing && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <div className="bg-white rounded-lg p-4 flex items-center gap-3">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-secondary"></div>
                <span className="font-medium">Analyzing with Gemini...</span>
              </div>
            </div>
          )}
        </div>

        {/* Detection Info */}
        {boundaries.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {boundaries.map((boundary, index) => (
              <div key={index} className="p-3 bg-muted rounded-lg text-center">
                <div className="font-bold text-secondary text-lg">{boundary.point}</div>
                <div className="text-xs text-muted-foreground">
                  ({boundary.coordinates[0]}, {boundary.coordinates[1]})
                </div>
                <div className="text-sm font-medium">{boundary.length}m</div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
