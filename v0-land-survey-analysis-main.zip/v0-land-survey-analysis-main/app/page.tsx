"use client"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Ruler, Target, Upload, Calculator, Zap, Brain, Cpu } from "lucide-react"
import { ImageUpload } from "@/components/image-upload"
import { BoundaryDetectionDisplay } from "@/components/boundary-detection-display"
import { EnhancedShapeDetectionDisplay } from "@/components/enhanced-shape-detection-display"
import { CalculationEngine } from "@/components/calculation-engine"
import { ResultsDashboard } from "@/components/results-dashboard"
import { UnitConversionPanel } from "@/components/unit-conversion-panel"
import { ManualTriangleCalculator } from "@/components/manual-triangle-calculator"

interface BoundaryPoint {
  point: string
  coordinates: [number, number]
  length: number
}

interface Triangle {
  id: number
  vertices: string[]
  area: number
  formula: string
}

interface DetectedShape {
  id: string
  type: string
  coordinates: [number, number][]
  measurements: { [key: string]: number }
  area: number
  confidence: number
  formula: string
  parentId?: string
  subshapes?: DetectedShape[]
  isSubshape: boolean
  depth: number
  extractedText?: string[]
  boundingBox?: {
    x: number
    y: number
    width: number
    height: number
  }
  processingMethod: "ai" | "cv" | "hybrid"
}

export default function LandSurveyApp() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [scaleReference, setScaleReference] = useState("")
  const [boundaries, setBoundaries] = useState<BoundaryPoint[]>([])
  const [detectedShapes, setDetectedShapes] = useState<DetectedShape[]>([])
  const [analysisMethod, setAnalysisMethod] = useState<"enhanced" | "legacy">("enhanced")
  const [results, setResults] = useState<any>(null)

  const handleImageUpload = (imageData: string, file: File) => {
    setUploadedImage(imageData)
    setUploadedFile(file)
    setBoundaries([]) // Reset boundaries when new image is uploaded
    setDetectedShapes([])
    setResults(null)
  }

  const handleRemoveImage = () => {
    setUploadedImage(null)
    setUploadedFile(null)
    setBoundaries([])
    setDetectedShapes([])
    setResults(null)
  }

  const handleBoundaryUpdate = (newBoundaries: BoundaryPoint[]) => {
    setBoundaries(newBoundaries)
    if (newBoundaries.length > 0) {
      // Auto-calculate results when boundaries are detected
      calculateResults(newBoundaries)
    }
  }

  const handleShapeUpdate = (newShapes: DetectedShape[]) => {
    setDetectedShapes(newShapes)
    if (newShapes.length > 0) {
      calculateEnhancedResults(newShapes)
    }
  }

  const calculateResults = (boundaryData: BoundaryPoint[]) => {
    // Mock calculation results based on detected boundaries
    const triangles: Triangle[] = [
      { id: 1, vertices: ["A", "B", "C"], area: 15000, formula: "Shoelace Formula" },
      { id: 2, vertices: ["A", "C", "D"], area: 15000, formula: "Shoelace Formula" },
    ]

    const totalArea = triangles.reduce((sum, triangle) => sum + triangle.area, 0)
    const totalAcres = totalArea / 43560 // Convert sq ft to acres

    setResults({
      boundaries: boundaryData,
      triangles,
      totalArea,
      totalAcres: Number.parseFloat(totalAcres.toFixed(3)),
      calculationMethod: "Automated Boundary Detection + Shoelace Formula",
      scaleReference,
      analysisType: "legacy",
    })
  }

  const calculateEnhancedResults = (shapeData: DetectedShape[]) => {
    const mainShapes = shapeData.filter((s) => !s.isSubshape)
    const subshapes = shapeData.filter((s) => s.isSubshape)

    const totalArea = shapeData.reduce((sum, shape) => sum + shape.area, 0)
    const totalAcres = totalArea / 4047 // Convert sq m to acres (assuming metric)

    const methodBreakdown = {
      ai: shapeData.filter((s) => s.processingMethod === "ai").length,
      cv: shapeData.filter((s) => s.processingMethod === "cv").length,
      hybrid: shapeData.filter((s) => s.processingMethod === "hybrid").length,
    }

    setResults({
      shapes: shapeData,
      mainShapes,
      subshapes,
      totalArea,
      totalAcres: Number.parseFloat(totalAcres.toFixed(4)),
      calculationMethod: "Enhanced AI + Computer Vision Shape Detection",
      scaleReference,
      analysisType: "enhanced",
      methodBreakdown,
      averageConfidence: shapeData.reduce((sum, s) => sum + s.confidence, 0) / shapeData.length,
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
                <Target className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Land Survey Assistant</h1>
                <p className="text-muted-foreground">Enhanced AI-Powered Shape Detection & Area Calculation</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={analysisMethod === "enhanced" ? "default" : "secondary"}>
                {analysisMethod === "enhanced" ? (
                  <>
                    <Zap className="w-3 h-3 mr-1" />
                    Enhanced AI + CV
                  </>
                ) : (
                  <>Legacy Detection</>
                )}
              </Badge>
              {results && (
                <Badge variant="outline">
                  {results.analysisType === "enhanced"
                    ? `${results.shapes?.length || 0} shapes detected`
                    : `${results.boundaries?.length || 0} boundaries detected`}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="ai-analysis" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="ai-analysis" className="flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  AI Analysis
                </TabsTrigger>
                <TabsTrigger value="manual-calculation" className="flex items-center gap-2">
                  <Calculator className="h-4 w-4" />
                  Manual Calculation
                </TabsTrigger>
              </TabsList>

              <TabsContent value="ai-analysis" className="space-y-6">
                {/* Upload Section */}
                <div className="space-y-4">
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Image Upload & Analysis</h2>
                    <p className="text-muted-foreground">
                      Upload your land plot image for automated shape detection and area calculation with enhanced AI +
                      Computer Vision
                    </p>
                  </div>

                  <ImageUpload
                    onImageUpload={handleImageUpload}
                    uploadedImage={uploadedImage}
                    onRemoveImage={handleRemoveImage}
                  />

                  {uploadedImage && (
                    <Card>
                      <CardContent className="p-4 space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="scale">Scale Reference (Optional)</Label>
                          <Input
                            id="scale"
                            placeholder="e.g., 'this line = 10 meters'"
                            value={scaleReference}
                            onChange={(e) => setScaleReference(e.target.value)}
                          />
                          <p className="text-xs text-muted-foreground">
                            Provide a scale reference to convert pixels to real-world units
                          </p>
                        </div>

                        <div className="flex items-center gap-4 p-3 bg-muted rounded-lg">
                          <Label className="font-medium">Analysis Method:</Label>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setAnalysisMethod("enhanced")}
                              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                                analysisMethod === "enhanced"
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-background text-muted-foreground hover:bg-muted"
                              }`}
                            >
                              <Zap className="w-3 h-3 mr-1 inline" />
                              Enhanced (AI + CV)
                            </button>
                            <button
                              onClick={() => setAnalysisMethod("legacy")}
                              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                                analysisMethod === "legacy"
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-background text-muted-foreground hover:bg-muted"
                              }`}
                            >
                              Legacy Detection
                            </button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {uploadedImage && analysisMethod === "enhanced" && (
                  <EnhancedShapeDetectionDisplay
                    image={uploadedImage}
                    shapes={detectedShapes}
                    onShapeUpdate={handleShapeUpdate}
                  />
                )}

                {uploadedImage && analysisMethod === "legacy" && (
                  <BoundaryDetectionDisplay
                    image={uploadedImage}
                    boundaries={boundaries}
                    onBoundaryUpdate={handleBoundaryUpdate}
                  />
                )}

                {/* Calculation Engine - Legacy only */}
                {boundaries.length > 0 && analysisMethod === "legacy" && (
                  <CalculationEngine
                    boundaries={boundaries}
                    onCalculationComplete={(result) => {
                      // Update results with calculation engine data
                      if (results) {
                        setResults({
                          ...results,
                          calculationMethod: result.formula,
                          calculationDetails: result.details,
                        })
                      }
                    }}
                  />
                )}

                {results && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Analysis Results</span>
                        <Badge variant={results.analysisType === "enhanced" ? "default" : "secondary"}>
                          {results.analysisType === "enhanced" ? "Enhanced Analysis" : "Legacy Analysis"}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {results.analysisType === "enhanced" ? (
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="text-center p-3 bg-blue-50 rounded-lg">
                              <div className="text-2xl font-bold text-blue-600">{results.shapes?.length || 0}</div>
                              <div className="text-sm text-blue-800">Total Shapes</div>
                            </div>
                            <div className="text-center p-3 bg-green-50 rounded-lg">
                              <div className="text-2xl font-bold text-green-600">{results.mainShapes?.length || 0}</div>
                              <div className="text-sm text-green-800">Main Shapes</div>
                            </div>
                            <div className="text-center p-3 bg-purple-50 rounded-lg">
                              <div className="text-2xl font-bold text-purple-600">{results.subshapes?.length || 0}</div>
                              <div className="text-sm text-purple-800">Subshapes</div>
                            </div>
                            <div className="text-center p-3 bg-orange-50 rounded-lg">
                              <div className="text-2xl font-bold text-orange-600">
                                {results.averageConfidence ? (results.averageConfidence * 100).toFixed(0) : 0}%
                              </div>
                              <div className="text-sm text-orange-800">Avg Confidence</div>
                            </div>
                          </div>

                          <div className="p-4 bg-primary/10 rounded-lg">
                            <div className="text-center">
                              <div className="text-3xl font-bold text-primary mb-2">
                                {results.totalArea.toFixed(2)} m²
                              </div>
                              <div className="text-lg text-primary/80">({results.totalAcres} acres)</div>
                              <div className="text-sm text-muted-foreground mt-2">
                                Method: {results.calculationMethod}
                              </div>
                            </div>
                          </div>

                          {results.methodBreakdown && (
                            <div className="grid grid-cols-3 gap-4 text-center">
                              <div className="p-2 bg-blue-50 rounded">
                                <div className="font-bold text-blue-600">{results.methodBreakdown.ai}</div>
                                <div className="text-xs text-blue-800">AI Detected</div>
                              </div>
                              <div className="p-2 bg-green-50 rounded">
                                <div className="font-bold text-green-600">{results.methodBreakdown.cv}</div>
                                <div className="text-xs text-green-800">CV Detected</div>
                              </div>
                              <div className="p-2 bg-purple-50 rounded">
                                <div className="font-bold text-purple-600">{results.methodBreakdown.hybrid}</div>
                                <div className="text-xs text-purple-800">Hybrid Validated</div>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <ResultsDashboard
                          boundaries={results.boundaries}
                          triangles={results.triangles}
                          totalArea={results.totalArea}
                          totalAcres={results.totalAcres}
                          calculationMethod={results.calculationMethod}
                          scaleReference={results.scaleReference}
                        />
                      )}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="manual-calculation" className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Manual Triangle Calculation</h2>
                    <p className="text-muted-foreground">
                      Calculate polygon area by dividing it into triangles and entering side measurements
                    </p>
                  </div>
                  <ManualTriangleCalculator />
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Unit Conversion Panel */}
            <UnitConversionPanel
              initialValue={results?.totalArea || 0}
              initialUnit={results?.analysisType === "enhanced" ? "sq_m" : "sq_ft"}
              onConversionUpdate={(value, unit, acres) => {
                // Handle conversion updates if needed
              }}
            />

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Ruler className="w-5 h-5" />
                  Enhanced Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      <Brain className="w-4 h-4" />
                      AI Detection
                    </h4>
                    <div className="space-y-1 text-xs text-muted-foreground ml-6">
                      <div>• Advanced shape recognition</div>
                      <div>• Hierarchical subshape detection</div>
                      <div>• Confidence scoring</div>
                      <div>• OCR text extraction</div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      <Cpu className="w-4 h-4" />
                      Computer Vision
                    </h4>
                    <div className="space-y-1 text-xs text-muted-foreground ml-6">
                      <div>• Edge detection algorithms</div>
                      <div>• Contour analysis</div>
                      <div>• Image preprocessing</div>
                      <div>• Geometric validation</div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Hybrid Processing
                    </h4>
                    <div className="space-y-1 text-xs text-muted-foreground ml-6">
                      <div>• Multi-method validation</div>
                      <div>• Result deduplication</div>
                      <div>• Enhanced accuracy</div>
                      <div>• Fallback mechanisms</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Supported Formulas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5" />
                  Supported Formulas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {[
                    "Heron's Formula (3 sides)",
                    "Base × Height",
                    "SAS (two sides + included angle)",
                    "ASA/AAS (via Law of Sines)",
                    "Equilateral triangle formula",
                    "Right triangle formula",
                    "Shoelace formula (coordinates)",
                    "Vector cross product formula",
                    "Circumradius formula",
                    "Inradius formula",
                    "Determinant formula",
                    "Surveying/Polygon extension",
                  ].map((formula, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">{formula}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
