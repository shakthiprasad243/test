import { google } from "@ai-sdk/google"
import { generateObject } from "ai"
import { z } from "zod"

const shapeDetectionSchema = z.object({
  shapes: z.array(
    z.object({
      id: z.string().describe("Shape identifier (S1, S2, etc. or S1.1, S1.2 for subshapes)"),
      type: z
        .enum(["triangle", "rectangle", "square", "circle", "polygon", "trapezoid", "parallelogram"])
        .describe("Detected shape type"),
      coordinates: z.array(z.array(z.number()).length(2)).describe("Shape vertices as [x, y] coordinates in pixels"),
      measurements: z.record(z.number()).describe("Shape measurements (sides, radius, diagonals, etc.)"),
      confidence: z.number().min(0).max(1).describe("Confidence in shape detection"),
      parentId: z
        .string()
        .optional()
        .describe("Parent shape ID if this is a subshape (e.g., 'S1' for subshape 'S1.1')"),
    }),
  ),
  scale: z.object({
    pixelsPerMeter: z.number().describe("Estimated pixels per meter ratio"),
    confidence: z.number().min(0).max(1).describe("Confidence in scale detection"),
  }),
  notes: z.string().describe("Additional observations about detected shapes and their relationships"),
})

export const maxDuration = 30

export async function POST(req: Request) {
  try {
    const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY
    if (!apiKey) {
      return Response.json({ error: "Google Generative AI API key is not configured" }, { status: 500 })
    }

    const { imageData } = await req.json()

    if (!imageData) {
      return Response.json({ error: "No image data provided" }, { status: 400 })
    }

    const base64Data = imageData.replace(/^data:image\/[a-z]+;base64,/, "")

    const { object } = await generateObject({
      model: google("gemini-2.0-flash-exp", { apiKey }),
      schema: shapeDetectionSchema,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this land survey image with ADVANCED HIERARCHICAL SHAPE DETECTION.

              PRIMARY OBJECTIVES:
              1. DETECT MAIN SHAPES: Identify the overall boundary shapes and major geometric forms
              2. DETECT SUBSHAPES: Find any shapes contained within or overlapping the main shapes
              3. HIERARCHICAL ANALYSIS: Establish parent-child relationships between shapes
              4. EFFICIENT FORMULAS: Use the most appropriate calculation method for each shape type
              5. COMPREHENSIVE AREA CALCULATION: Calculate individual areas and combined totals

              DETECTION METHODOLOGY:
              
              MAIN SHAPES (Level 0):
              - Overall property boundaries
              - Major structural shapes (buildings, lots, etc.)
              - Primary geometric forms
              - Label as: S1, S2, S3, etc.
              
              SUBSHAPES (Level 1+):
              - Shapes contained within main shapes
              - Overlapping or intersecting areas
              - Internal divisions or structures
              - Label as: S1.1, S1.2, S2.1, etc. (with parentId set to parent)
              
              SHAPE-SPECIFIC REQUIREMENTS:
              - Triangle: provide "a", "b", "c" (all three sides) → Use Heron's formula
              - Rectangle: provide "width", "height" → Use width × height
              - Square: provide "side" → Use side²
              - Circle: provide "radius" → Use π × radius²
              - Polygon: provide all vertices and sides → Use shoelace formula
              
              HIERARCHICAL RELATIONSHIPS:
              - Set parentId for subshapes (e.g., if S1.1 is inside S1, set parentId: "S1")
              - Ensure geometric consistency (subshapes must fit within parents)
              - Identify overlapping areas that need special handling
              
              MEASUREMENT ACCURACY:
              - Determine scale from reference objects or typical survey dimensions
              - Typical residential: 10-200m sides, 0.01-2 acre areas
              - Commercial/agricultural: larger scales possible
              - Validate geometric constraints for each shape type
              
              COMPREHENSIVE ANALYSIS:
              - Calculate area for each individual shape using optimal formula
              - Identify potential overlaps between shapes
              - Note any complex geometric relationships
              - Provide detailed observations about shape hierarchy
              
              Focus on detecting ALL shapes at ALL levels with maximum accuracy and proper hierarchical relationships.`,
            },
            {
              type: "image",
              image: base64Data,
            },
          ],
        },
      ],
      maxTokens: 4000,
    })

    return Response.json({
      success: true,
      data: object,
      provider: "gemini",
    })
  } catch (error) {
    console.error("Gemini shape analysis error:", error)
    return Response.json(
      {
        error: "Failed to analyze shapes with Gemini",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
