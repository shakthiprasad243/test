import { google } from "@ai-sdk/google"
import { generateObject } from "ai"
import { z } from "zod"

const boundaryDetectionSchema = z.object({
  boundaries: z.array(
    z.object({
      point: z.string().describe("Boundary point label (A, B, C, etc.)"),
      coordinates: z.array(z.number()).length(2).describe("X, Y coordinates in pixels"),
      length: z.number().describe("Side length in meters (estimated from scale)"),
    }),
  ),
  scale: z.object({
    pixelsPerMeter: z.number().describe("Estimated pixels per meter ratio"),
    confidence: z.number().min(0).max(1).describe("Confidence in scale detection"),
  }),
  totalArea: z.number().describe("Estimated total area in square meters"),
  notes: z.string().describe("Additional observations about the land plot"),
})

export const maxDuration = 30

export async function POST(req: Request) {
  try {
    const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY
    if (!apiKey) {
      return Response.json({ error: "Google Generative AI API key is not configured" }, { status: 500 })
    }

    const { imageData } = await req.json()

    if (!imageData) {
      return Response.json({ error: "No image data provided" }, { status: 400 })
    }

    // Remove data URL prefix if present
    const base64Data = imageData.replace(/^data:image\/[a-z]+;base64,/, "")

    const { object } = await generateObject({
      model: google("gemini-2.0-flash-exp", { apiKey }),
      schema: boundaryDetectionSchema,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this land survey image and detect the boundaries of the plot with high accuracy.
              
              CRITICAL VALIDATION REQUIREMENTS:
              1. Identify all visible boundary lines and corners
              2. Label each corner point (A, B, C, D, etc.) in clockwise order
              3. Estimate coordinates in pixels from top-left origin
              4. Determine scale by looking for reference objects, measurements, or typical land plot sizes
              5. Estimate side lengths in meters - ENSURE TRIANGLE INEQUALITY IS SATISFIED
              6. For any triangle formed by three consecutive sides, verify: a + b > c, a + c > b, b + c > a
              7. Calculate approximate total area using appropriate geometric formulas
              8. Cross-validate measurements for consistency
              
              MEASUREMENT GUIDELINES:
              - Typical residential lots: 0.1-2 acres (400-8000 sq meters)
              - Typical side lengths: 10-200 meters
              - Ensure measurements are physically realistic
              - If uncertain about scale, err on the side of typical residential plot sizes
              
              Provide confidence assessment and detailed notes about measurement methodology.`,
            },
            {
              type: "image",
              image: base64Data,
            },
          ],
        },
      ],
      maxTokens: 2000,
    })

    return Response.json({
      success: true,
      data: object,
      provider: "gemini",
    })
  } catch (error) {
    console.error("Gemini boundary analysis error:", error)
    return Response.json(
      {
        error: "Failed to analyze boundaries with Gemini",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
